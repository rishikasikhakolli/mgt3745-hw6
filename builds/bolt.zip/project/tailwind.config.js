/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        primary: {
          DEFAULT: '#DD2A7B',
          light: '#E85CA0',
          dark: '#B01E62',
        },
        accent: {
          DEFAULT: '#00C853',
          light: '#5AE892',
          dark: '#009E3D',
        },
        background: '#FFFFFF',
        ink: '#1A1A1A',
        muted: '#6B6B6B',
        line: '#E5E5E5',
        surface: '#F7F7F7',
      },
      fontFamily: {
        body: ['Roboto', 'system-ui', 'sans-serif'],
        heading: ['Georgia', 'serif'],
      },
      spacing: {
        unit: '8px',
      },
      borderRadius: {
        DEFAULT: '4px',
        card: '8px',
      },
      maxWidth: {
        feed: '640px',
      },
      boxShadow: {
        card: '0 1px 3px rgba(0,0,0,0.06), 0 1px 2px rgba(0,0,0,0.04)',
        pop: '0 4px 16px rgba(221,42,123,0.15)',
      },
      keyframes: {
        'fade-in-up': {
          '0%': { opacity: '0', transform: 'translateY(12px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        'fade-in': {
          '0%': { opacity: '0' },
          '100%': { opacity: '1' },
        },
        'scale-in': {
          '0%': { opacity: '0', transform: 'scale(0.96)' },
          '100%': { opacity: '1', transform: 'scale(1)' },
        },
        'slide-up': {
          '0%': { opacity: '0', transform: 'translateY(100%)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        'slide-down': {
          '0%': { opacity: '0', transform: 'translateY(-12px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
      },
      animation: {
        'fade-in-up': 'fade-in-up 0.4s ease-out',
        'fade-in': 'fade-in 0.3s ease-out',
        'scale-in': 'scale-in 0.2s ease-out',
        'slide-up': 'slide-up 0.3s cubic-bezier(0.16,1,0.3,1)',
        'slide-down': 'slide-down 0.3s ease-out',
      },
    },
  },
  plugins: [],
};
