import { MapPin } from 'lucide-react';
import type { Moment } from '@/lib/types';

function formatRelativeTime(iso: string): string {
  const date = new Date(iso);
  const now = new Date();
  const diffMs = now.getTime() - date.getTime();
  const diffMin = Math.floor(diffMs / 60000);
  const diffHr = Math.floor(diffMin / 60);
  const diffDay = Math.floor(diffHr / 24);

  if (diffMin < 1) return 'just now';
  if (diffMin < 60) return `${diffMin}m ago`;
  if (diffHr < 24) return `${diffHr}h ago`;
  if (diffDay < 7) return `${diffDay}d ago`;
  return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
}

export default function MomentCard({ moment }: { moment: Moment }) {
  return (
    <article className="bg-white rounded-card shadow-card overflow-hidden animate-fade-in-up">
      <div className="flex items-center justify-between px-4 pt-3 pb-2">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-full bg-primary text-white flex items-center justify-center text-xs font-body font-bold">
            {moment.member_name.charAt(0).toUpperCase()}
          </div>
          <span className="text-sm font-body font-medium text-ink">
            {moment.member_name}
          </span>
        </div>
        <span className="text-xs text-muted font-body">
          {formatRelativeTime(moment.created_at)}
        </span>
      </div>

      {moment.photo_url && (
        <div className="w-full bg-surface">
          <img
            src={moment.photo_url}
            alt={moment.place || 'Moment photo'}
            className="w-full max-h-[500px] object-cover"
            loading="lazy"
          />
        </div>
      )}

      <div className="px-4 py-3 space-y-2">
        {moment.note && (
          <p className="text-sm font-body text-ink leading-relaxed">
            {moment.note}
          </p>
        )}
        {moment.place && (
          <div className="flex items-center gap-1.5">
            <MapPin size={14} className="text-accent flex-shrink-0" />
            <span className="text-sm font-body text-accent font-medium">
              {moment.place}
            </span>
          </div>
        )}
      </div>
    </article>
  );
}
