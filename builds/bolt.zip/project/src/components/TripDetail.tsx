import { useState, useEffect, useCallback } from 'react';
import { useAuth } from '@/lib/auth';
import { supabase, type Trip, type Moment } from '@/lib/supabase';
import { getPhotoUrl, formatRelativeTime } from '@/lib/utils';
import AddMomentForm from './AddMomentForm';
import { ArrowLeft, Plus, MapPin, Camera, Type, Trash2, MessageCircle } from 'lucide-react';

type Props = {
  tripId: string;
  onBack: () => void;
};

export default function TripDetail({ tripId, onBack }: Props) {
  const { user, displayName } = useAuth();
  const [trip, setTrip] = useState<Trip | null>(null);
  const [moments, setMoments] = useState<Moment[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const loadTrip = useCallback(async () => {
    const { data, error } = await supabase
      .from('trips')
      .select('*')
      .eq('id', tripId)
      .maybeSingle();

    if (error || !data) {
      setError('Could not load this trip.');
      setLoading(false);
      return;
    }
    setTrip(data);
  }, [tripId]);

  const loadMoments = useCallback(async () => {
    const { data, error } = await supabase
      .from('moments')
      .select('*')
      .eq('trip_id', tripId)
      .order('created_at', { ascending: false });

    if (error) {
      setError('Could not load moments.');
    } else {
      setMoments(data || []);
      setError(null);
    }
    setLoading(false);
  }, [tripId]);

  useEffect(() => {
    loadTrip();
    loadMoments();
  }, [loadTrip, loadMoments]);

  const handleMomentAdded = () => {
    setShowForm(false);
    loadMoments();
  };

  const handleDeleteMoment = async (momentId: string) => {
    const moment = moments.find((m) => m.id === momentId);
    if (!moment) return;

    const { error } = await supabase.from('moments').delete().eq('id', momentId);
    if (error) {
      setError('Could not delete moment.');
      return;
    }

    // Clean up photo from storage
    if (moment.photo_url) {
      await supabase.storage.from('moment-photos').remove([moment.photo_url]);
    }

    setMoments((prev) => prev.filter((m) => m.id !== momentId));
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-white">
        <div className="max-w-2xl mx-auto px-6 py-8">
          <div className="h-6 w-32 rounded animate-pulse mb-4" style={{ backgroundColor: '#F0F0F0' }} />
          <div className="h-8 w-2/3 rounded animate-pulse mb-8" style={{ backgroundColor: '#F0F0F0' }} />
          <div className="space-y-4">
            {[1, 2].map((i) => (
              <div key={i} className="card p-5 animate-pulse" style={{ borderRadius: '4px' }}>
                <div className="h-4 w-1/4 rounded" style={{ backgroundColor: '#F0F0F0' }} />
                <div className="h-32 w-full rounded mt-3" style={{ backgroundColor: '#F0F0F0' }} />
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="sticky top-0 z-10 bg-white/95 backdrop-blur-sm border-b" style={{ borderColor: '#E8E8E8' }}>
        <div className="max-w-2xl mx-auto px-6 h-14 flex items-center gap-3">
          <button onClick={onBack} className="text-gray-600 hover:text-gray-900 transition-colors">
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h1 className="text-base truncate" style={{ fontFamily: 'Georgia, serif' }}>
            {trip?.title || 'Trip'}
          </h1>
        </div>
      </header>

      <div className="max-w-2xl mx-auto px-6 py-8">
        {/* Trip header */}
        <div className="mb-6">
          <h2 className="text-2xl mb-1" style={{ fontFamily: 'Georgia, serif' }}>{trip?.title}</h2>
          {trip?.description && (
            <p className="text-sm text-gray-500">{trip.description}</p>
          )}
        </div>

        {error && (
          <div className="mb-4 text-sm rounded p-3" style={{ backgroundColor: '#FFF0F3', color: '#DD2A7B', borderRadius: '4px' }}>
            {error}
          </div>
        )}

        {/* Add moment button / form */}
        {showForm ? (
          <div className="mb-6">
            <AddMomentForm
              tripId={tripId}
              onAdded={handleMomentAdded}
              onCancel={() => setShowForm(false)}
            />
          </div>
        ) : (
          <button
            onClick={() => setShowForm(true)}
            className="btn-primary w-full mb-6"
            style={{ borderRadius: '4px' }}
          >
            <Plus className="w-4 h-4" />
            Add a Moment
          </button>
        )}

        {/* Moments feed */}
        {moments.length === 0 ? (
          <div className="text-center py-16">
            <div className="w-14 h-14 rounded-full flex items-center justify-center mx-auto mb-3"
                 style={{ backgroundColor: '#FDF2F7' }}>
              <MessageCircle className="w-7 h-7" style={{ color: '#DD2A7B' }} />
            </div>
            <h3 className="text-base mb-1" style={{ fontFamily: 'Georgia, serif' }}>No moments yet</h3>
            <p className="text-sm text-gray-500">Share a photo, note, or place from this trip.</p>
          </div>
        ) : (
          <div className="space-y-4">
            {moments.map((moment) => (
              <MomentCard
                key={moment.id}
                moment={moment}
                canDelete={moment.author_id === user?.id}
                onDelete={handleDeleteMoment}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function MomentCard({
  moment,
  canDelete,
  onDelete,
}: {
  moment: Moment;
  canDelete: boolean;
  onDelete: (id: string) => void;
}) {
  const hasPhoto = !!moment.photo_url;
  const hasNote = !!moment.note;
  const hasPlace = !!moment.place;

  return (
    <div className="card overflow-hidden" style={{ borderRadius: '4px' }}>
      {/* Author row */}
      <div className="flex items-center justify-between px-5 py-3">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-full flex items-center justify-center"
               style={{ backgroundColor: '#FDF2F7' }}>
            <span className="text-xs font-medium" style={{ color: '#DD2A7B' }}>
              {moment.author_name.charAt(0).toUpperCase()}
            </span>
          </div>
          <div>
            <span className="text-sm font-medium">{moment.author_name}</span>
            <span className="text-xs text-gray-400 ml-2">{formatRelativeTime(moment.created_at)}</span>
          </div>
        </div>
        {canDelete && (
          <button
            onClick={() => onDelete(moment.id)}
            className="text-gray-300 hover:text-gray-500 transition-colors"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        )}
      </div>

      {/* Photo */}
      {hasPhoto && (
        <div className="px-5 pb-3">
          <img
            src={getPhotoUrl(moment.photo_url!)}
            alt={moment.place || 'Trip moment'}
            className="w-full max-h-96 object-cover rounded"
            style={{ borderRadius: '4px' }}
            loading="lazy"
          />
        </div>
      )}

      {/* Place */}
      {hasPlace && (
        <div className="px-5 pb-2">
          <div className="flex items-center gap-1.5">
            <MapPin className="w-3.5 h-3.5" style={{ color: '#00C853' }} />
            <span className="text-sm font-medium" style={{ color: '#00A040' }}>{moment.place}</span>
          </div>
        </div>
      )}

      {/* Note */}
      {hasNote && (
        <div className="px-5 pb-4">
          <p className="text-sm leading-relaxed" style={{ lineHeight: '1.6', color: '#1A1A1A' }}>
            {moment.note}
          </p>
        </div>
      )}

      {/* Tags for content type (when no photo) */}
      {!hasPhoto && (hasNote || hasPlace) && (
        <div className="px-5 pb-4 flex gap-2">
          {hasNote && (
            <span className="inline-flex items-center gap-1 text-xs px-2 py-1 rounded"
                  style={{ backgroundColor: '#F5F5F5', color: '#777', borderRadius: '4px' }}>
              <Type className="w-3 h-3" /> Note
            </span>
          )}
          {hasPlace && (
            <span className="inline-flex items-center gap-1 text-xs px-2 py-1 rounded"
                  style={{ backgroundColor: '#E8F8EE', color: '#00A040', borderRadius: '4px' }}>
              <MapPin className="w-3 h-3" /> Place
            </span>
          )}
        </div>
      )}
    </div>
  );
}
