import { useState } from 'react';
import { useAuth } from '@/lib/auth';
import { Compass } from 'lucide-react';

export default function AuthScreen() {
  const { signIn, signUp } = useAuth();
  const [mode, setMode] = useState<'signin' | 'signup'>('signin');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSubmitting(true);

    if (mode === 'signup' && !name.trim()) {
      setError('Please enter your name.');
      setSubmitting(false);
      return;
    }

    const result =
      mode === 'signin'
        ? await signIn(email, password)
        : await signUp(email, password, name.trim());

    if (result.error) {
      setError(result.error);
      setSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center px-6 py-12 bg-white">
      <div className="w-full max-w-sm">
        <div className="flex flex-col items-center mb-8">
          <div className="w-14 h-14 rounded-full flex items-center justify-center mb-3"
               style={{ backgroundColor: '#DD2A7B' }}>
            <Compass className="w-7 h-7 text-white" />
          </div>
          <h1 className="text-2xl font-normal tracking-tight" style={{ fontFamily: 'Georgia, serif' }}>
            Trip Moments
          </h1>
          <p className="text-sm text-gray-500 mt-1">Share your travels with friends</p>
        </div>

        <div className="card p-6" style={{ borderRadius: '4px', border: '1px solid #E8E8E8' }}>
          <div className="flex gap-1 mb-6 p-1 rounded" style={{ backgroundColor: '#F5F5F5', borderRadius: '4px' }}>
            <button
              onClick={() => { setMode('signin'); setError(null); }}
              className="flex-1 py-2 text-sm font-medium rounded transition-all"
              style={{
                borderRadius: '4px',
                backgroundColor: mode === 'signin' ? '#FFFFFF' : 'transparent',
                color: mode === 'signin' ? '#1A1A1A' : '#999',
                boxShadow: mode === 'signin' ? '0 1px 2px rgba(0,0,0,0.08)' : 'none',
              }}
            >
              Sign In
            </button>
            <button
              onClick={() => { setMode('signup'); setError(null); }}
              className="flex-1 py-2 text-sm font-medium rounded transition-all"
              style={{
                borderRadius: '4px',
                backgroundColor: mode === 'signup' ? '#FFFFFF' : 'transparent',
                color: mode === 'signup' ? '#1A1A1A' : '#999',
                boxShadow: mode === 'signup' ? '0 1px 2px rgba(0,0,0,0.08)' : 'none',
              }}
            >
              Sign Up
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            {mode === 'signup' && (
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1.5">Name</label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Your name"
                  className="input-field"
                  style={{ fontSize: '14px', borderRadius: '4px' }}
                />
              </div>
            )}
            <div>
              <label className="block text-xs font-medium text-gray-600 mb-1.5">Email</label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@example.com"
                className="input-field"
                style={{ fontSize: '14px', borderRadius: '4px' }}
                required
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-600 mb-1.5">Password</label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="input-field"
                style={{ fontSize: '14px', borderRadius: '4px' }}
                required
                minLength={6}
              />
            </div>

            {error && (
              <div className="text-sm rounded p-3" style={{ backgroundColor: '#FFF0F3', color: '#DD2A7B', borderRadius: '4px' }}>
                {error}
              </div>
            )}

            <button
              type="submit"
              disabled={submitting}
              className="btn-primary w-full"
              style={{ borderRadius: '4px' }}
            >
              {submitting ? 'Please wait...' : mode === 'signin' ? 'Sign In' : 'Create Account'}
            </button>
          </form>
        </div>

        <p className="text-center text-xs text-gray-400 mt-6">
          {mode === 'signin' ? "Don't have an account? " : 'Already have an account? '}
          <button
            onClick={() => { setMode(mode === 'signin' ? 'signup' : 'signin'); setError(null); }}
            className="font-medium"
            style={{ color: '#DD2A7B' }}
          >
            {mode === 'signin' ? 'Sign up' : 'Sign in'}
          </button>
        </p>
      </div>
    </div>
  );
}
