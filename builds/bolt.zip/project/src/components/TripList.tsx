import { useState, useEffect, useCallback } from 'react';
import { useAuth } from '@/lib/auth';
import { supabase, type Trip } from '@/lib/supabase';
import { Compass, Plus, MapPin, LogOut, X } from 'lucide-react';
import { formatRelativeTime } from '@/lib/utils';

export default function TripList({ onOpenTrip }: { onOpenTrip: (tripId: string) => void }) {
  const { displayName, signOut } = useAuth();
  const [trips, setTrips] = useState<Trip[]>([]);
  const [loading, setLoading] = useState(true);
  const [showCreate, setShowCreate] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newDesc, setNewDesc] = useState('');
  const [creating, setCreating] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const loadTrips = useCallback(async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from('trips')
      .select('*')
      .order('created_at', { ascending: false });

    if (error) {
      setError('Could not load your trips.');
    } else {
      setTrips(data || []);
      setError(null);
    }
    setLoading(false);
  }, []);

  useEffect(() => {
    loadTrips();
  }, [loadTrips]);

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;
    setCreating(true);
    setError(null);

    const { data, error } = await supabase
      .from('trips')
      .insert({ title: newTitle.trim(), description: newDesc.trim() || null })
      .select()
      .single();

    if (error) {
      setError('Could not create trip. Please try again.');
      setCreating(false);
      return;
    }

    setNewTitle('');
    setNewDesc('');
    setShowCreate(false);
    setCreating(false);
    setTrips((prev) => [data, ...prev]);
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="sticky top-0 z-10 bg-white/95 backdrop-blur-sm border-b" style={{ borderColor: '#E8E8E8' }}>
        <div className="max-w-2xl mx-auto px-6 h-14 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Compass className="w-5 h-5" style={{ color: '#DD2A7B' }} />
            <span className="text-base" style={{ fontFamily: 'Georgia, serif' }}>Trip Moments</span>
          </div>
          <div className="flex items-center gap-3">
            <span className="text-sm text-gray-500">{displayName}</span>
            <button onClick={signOut} className="text-gray-400 hover:text-gray-600 transition-colors">
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        </div>
      </header>

      {/* Content */}
      <div className="max-w-2xl mx-auto px-6 py-8">
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-2xl" style={{ fontFamily: 'Georgia, serif' }}>Your Trips</h1>
          <button
            onClick={() => setShowCreate(true)}
            className="btn-primary"
            style={{ borderRadius: '4px' }}
          >
            <Plus className="w-4 h-4" />
            New Trip
          </button>
        </div>

        {error && (
          <div className="mb-4 text-sm rounded p-3" style={{ backgroundColor: '#FFF0F3', color: '#DD2A7B', borderRadius: '4px' }}>
            {error}
          </div>
        )}

        {loading ? (
          <div className="space-y-3">
            {[1, 2, 3].map((i) => (
              <div key={i} className="card p-5 animate-pulse" style={{ borderRadius: '4px' }}>
                <div className="h-5 w-1/3 rounded" style={{ backgroundColor: '#F0F0F0' }} />
                <div className="h-4 w-2/3 rounded mt-2" style={{ backgroundColor: '#F0F0F0' }} />
              </div>
            ))}
          </div>
        ) : trips.length === 0 ? (
          <div className="text-center py-20">
            <div className="w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4"
                 style={{ backgroundColor: '#FDF2F7' }}>
              <MapPin className="w-8 h-8" style={{ color: '#DD2A7B' }} />
            </div>
            <h2 className="text-lg mb-1" style={{ fontFamily: 'Georgia, serif' }}>No trips yet</h2>
            <p className="text-sm text-gray-500 mb-6">Create your first trip to start sharing moments.</p>
            <button
              onClick={() => setShowCreate(true)}
              className="btn-primary"
              style={{ borderRadius: '4px' }}
            >
              <Plus className="w-4 h-4" />
              Create Trip
            </button>
          </div>
        ) : (
          <div className="space-y-3">
            {trips.map((trip) => (
              <button
                key={trip.id}
                onClick={() => onOpenTrip(trip.id)}
                className="card p-5 w-full text-left transition-all hover:shadow-md"
                style={{ borderRadius: '4px' }}
              >
                <h3 className="text-lg mb-1" style={{ fontFamily: 'Georgia, serif' }}>{trip.title}</h3>
                {trip.description && (
                  <p className="text-sm text-gray-500 line-clamp-2">{trip.description}</p>
                )}
                <p className="text-xs text-gray-400 mt-2">Created {formatRelativeTime(trip.created_at)}</p>
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Create trip modal */}
      {showCreate && (
        <div className="fixed inset-0 z-20 flex items-center justify-center px-6"
             style={{ backgroundColor: 'rgba(0,0,0,0.4)' }}
             onClick={() => setShowCreate(false)}>
          <div className="bg-white w-full max-w-sm rounded p-6"
               style={{ borderRadius: '4px' }}
               onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg" style={{ fontFamily: 'Georgia, serif' }}>New Trip</h2>
              <button onClick={() => setShowCreate(false)} className="text-gray-400 hover:text-gray-600">
                <X className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={handleCreate} className="space-y-4">
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1.5">Trip Title</label>
                <input
                  type="text"
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  placeholder="Weekend in Lisbon"
                  className="input-field"
                  style={{ fontSize: '14px', borderRadius: '4px' }}
                  autoFocus
                  required
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1.5">Description (optional)</label>
                <textarea
                  value={newDesc}
                  onChange={(e) => setNewDesc(e.target.value)}
                  placeholder="A quick note about this trip..."
                  className="input-field resize-none"
                  style={{ fontSize: '14px', borderRadius: '4px' }}
                  rows={3}
                />
              </div>
              {error && (
                <div className="text-sm rounded p-3" style={{ backgroundColor: '#FFF0F3', color: '#DD2A7B', borderRadius: '4px' }}>
                  {error}
                </div>
              )}
              <button
                type="submit"
                disabled={creating || !newTitle.trim()}
                className="btn-primary w-full"
                style={{ borderRadius: '4px' }}
              >
                {creating ? 'Creating...' : 'Create Trip'}
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
