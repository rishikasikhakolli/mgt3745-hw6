import { Calendar, MapPin, Plus } from 'lucide-react';
import type { Trip } from '@/lib/types';

interface TripHeaderProps {
  trip: Trip;
  momentCount: number;
  onAddClick: () => void;
  isAdding: boolean;
}

function formatDate(dateStr: string | null): string {
  if (!dateStr) return '';
  return new Date(dateStr).toLocaleDateString('en-US', {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
  });
}

export default function TripHeader({ trip, momentCount, onAddClick, isAdding }: TripHeaderProps) {
  const dateRange =
    trip.start_date && trip.end_date
      ? `${formatDate(trip.start_date)} - ${formatDate(trip.end_date)}`
      : '';

  return (
    <div className="bg-white border-b border-line sticky top-0 z-10">
      <div className="max-w-feed mx-auto px-4 pt-6 pb-4">
        <div className="flex items-start justify-between gap-4">
          <div className="flex-1 min-w-0">
            <h1 className="font-heading text-2xl text-ink mb-1">{trip.title}</h1>
            {trip.destination && (
              <div className="flex items-center gap-1.5 text-muted mb-2">
                <MapPin size={15} className="flex-shrink-0" />
                <span className="text-sm font-body">{trip.destination}</span>
              </div>
            )}
            {dateRange && (
              <div className="flex items-center gap-1.5 text-muted">
                <Calendar size={15} className="flex-shrink-0" />
                <span className="text-sm font-body">{dateRange}</span>
              </div>
            )}
          </div>
          <button
            onClick={onAddClick}
            className="inline-flex items-center gap-2 px-4 py-2 rounded bg-primary text-white text-sm font-body font-medium hover:bg-primary-dark transition-colors shadow-pop flex-shrink-0"
          >
            <Plus size={16} />
            Add moment
          </button>
        </div>
        <div className="mt-3">
          <span className="text-xs font-body text-muted">
            {momentCount} {momentCount === 1 ? 'moment' : 'moments'} shared
          </span>
        </div>
      </div>
    </div>
  );
}
