import { useState, useRef, useCallback } from 'react';
import { useAuth } from '@/lib/auth';
import { supabase } from '@/lib/supabase';
import { getPhotoUrl } from '@/lib/utils';
import { Camera, MapPin, X, Loader2, Image as ImageIcon, Type } from 'lucide-react';

type Props = {
  tripId: string;
  onAdded: () => void;
  onCancel: () => void;
};

export default function AddMomentForm({ tripId, onAdded, onCancel }: Props) {
  const { displayName } = useAuth();
  const [photo, setPhoto] = useState<File | null>(null);
  const [photoPreview, setPhotoPreview] = useState<string | null>(null);
  const [note, setNote] = useState('');
  const [place, setPlace] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [validationError, setValidationError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handlePhotoSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 10 * 1024 * 1024) {
      setError('Photo is too large (max 10MB).');
      return;
    }
    setPhoto(file);
    setPhotoPreview(URL.createObjectURL(file));
    setError(null);
  };

  const clearPhoto = () => {
    setPhoto(null);
    if (photoPreview) URL.revokeObjectURL(photoPreview);
    setPhotoPreview(null);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    // Validation: at least one of photo, note, or place must be provided
    if (!photo && !note.trim() && !place.trim()) {
      setValidationError('Add at least a photo, note, or place to share a moment.');
      return;
    }

    setValidationError(null);
    setError(null);
    setSubmitting(true);

    try {
      let photoUrl: string | null = null;

      // Upload photo if one was selected
      if (photo) {
        const fileExt = photo.name.split('.').pop() || 'jpg';
        const fileName = `${tripId}/${Date.now()}-${Math.random().toString(36).slice(2)}.${fileExt}`;
        const { error: uploadError } = await supabase.storage
          .from('moment-photos')
          .upload(fileName, photo);

        if (uploadError) {
          throw new Error('Could not upload photo. Please try again.');
        }
        photoUrl = fileName;
      }

      // Insert the moment
      const { error: insertError } = await supabase.from('moments').insert({
        trip_id: tripId,
        author_name: displayName || 'Anonymous',
        photo_url: photoUrl,
        note: note.trim() || null,
        place: place.trim() || null,
      });

      if (insertError) {
        throw new Error('Could not save your moment. Please try again.');
      }

      // Clean up preview
      if (photoPreview) URL.revokeObjectURL(photoPreview);

      // Reset form
      setPhoto(null);
      setPhotoPreview(null);
      setNote('');
      setPlace('');
      if (fileInputRef.current) fileInputRef.current.value = '';

      onAdded();
    } catch (err) {
      // Keep everything on screen so the user can try again
      setError(err instanceof Error ? err.message : 'Something went wrong. Please try again.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="card overflow-hidden" style={{ borderRadius: '4px' }}>
      {/* Form header */}
      <div className="flex items-center justify-between px-5 py-3 border-b" style={{ borderColor: '#E8E8E8' }}>
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-full flex items-center justify-center"
               style={{ backgroundColor: '#FDF2F7' }}>
            <span className="text-xs font-medium" style={{ color: '#DD2A7B' }}>
              {(displayName || '?').charAt(0).toUpperCase()}
            </span>
          </div>
          <span className="text-sm font-medium">{displayName}</span>
        </div>
        <button onClick={onCancel} className="text-gray-400 hover:text-gray-600 transition-colors">
          <X className="w-4 h-4" />
        </button>
      </div>

      <form onSubmit={handleSubmit} className="p-5 space-y-4">
        {/* Photo upload */}
        <div>
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            onChange={handlePhotoSelect}
            className="hidden"
          />
          {photoPreview ? (
            <div className="relative rounded overflow-hidden" style={{ borderRadius: '4px' }}>
              <img src={photoPreview} alt="Preview" className="w-full max-h-80 object-cover" />
              <button
                type="button"
                onClick={clearPhoto}
                disabled={submitting}
                className="absolute top-2 right-2 w-8 h-8 rounded-full flex items-center justify-center transition-all"
                style={{ backgroundColor: 'rgba(0,0,0,0.6)', borderRadius: '4px' }}
              >
                <X className="w-4 h-4 text-white" />
              </button>
            </div>
          ) : (
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              disabled={submitting}
              className="w-full py-10 flex flex-col items-center gap-2 rounded border-2 border-dashed transition-all hover:bg-gray-50"
              style={{ borderColor: '#E0E0E0', borderRadius: '4px' }}
            >
              <Camera className="w-8 h-8 text-gray-400" />
              <span className="text-sm text-gray-500">Add a photo</span>
            </button>
          )}
        </div>

        {/* Note */}
        <div>
          <div className="flex items-center gap-2 mb-1.5">
            <Type className="w-3.5 h-3.5 text-gray-400" />
            <label className="text-xs font-medium text-gray-600">Note</label>
          </div>
          <textarea
            value={note}
            onChange={(e) => setNote(e.target.value)}
            placeholder="A quick story or thought..."
            className="input-field resize-none"
            style={{ fontSize: '14px', borderRadius: '4px' }}
            rows={3}
            disabled={submitting}
          />
        </div>

        {/* Place */}
        <div>
          <div className="flex items-center gap-2 mb-1.5">
            <MapPin className="w-3.5 h-3.5 text-gray-400" />
            <label className="text-xs font-medium text-gray-600">Place</label>
          </div>
          <input
            type="text"
            value={place}
            onChange={(e) => setPlace(e.target.value)}
            placeholder="Cafe da Manha, Lisbon"
            className="input-field"
            style={{ fontSize: '14px', borderRadius: '4px' }}
            disabled={submitting}
          />
        </div>

        {/* Validation error - refuses empty submission */}
        {validationError && (
          <div className="text-sm rounded p-3 flex items-start gap-2"
               style={{ backgroundColor: '#FFF3E0', color: '#E65100', borderRadius: '4px' }}>
            <ImageIcon className="w-4 h-4 flex-shrink-0 mt-0.5" />
            {validationError}
          </div>
        )}

        {/* Save error - tells member, keeps data on screen */}
        {error && (
          <div className="text-sm rounded p-3" style={{ backgroundColor: '#FFF0F3', color: '#DD2A7B', borderRadius: '4px' }}>
            {error}
          </div>
        )}

        {/* Actions */}
        <div className="flex gap-3 pt-1">
          <button
            type="button"
            onClick={onCancel}
            disabled={submitting}
            className="btn-secondary flex-1"
            style={{ borderRadius: '4px' }}
          >
            Cancel
          </button>
          <button
            type="submit"
            disabled={submitting}
            className="btn-primary flex-1"
            style={{ borderRadius: '4px' }}
          >
            {submitting ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                Saving...
              </>
            ) : (
              'Share Moment'
            )}
          </button>
        </div>
      </form>
    </div>
  );
}
