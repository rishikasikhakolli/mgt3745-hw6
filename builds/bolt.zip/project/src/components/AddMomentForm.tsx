import { useRef, useState } from 'react';
import { Camera, MapPin, X, Send, AlertCircle, Loader2 } from 'lucide-react';
import { supabase } from '@/lib/supabase';

interface AddMomentFormProps {
  tripId: string;
  onSaved: () => void;
}

export default function AddMomentForm({ tripId, onSaved }: AddMomentFormProps) {
  const [memberName, setMemberName] = useState('');
  const [note, setNote] = useState('');
  const [place, setPlace] = useState('');
  const [photo, setPhoto] = useState<File | null>(null);
  const [photoPreview, setPhotoPreview] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  function handlePhotoSelect(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    setPhoto(file);
    setPhotoPreview(URL.createObjectURL(file));
  }

  function clearPhoto() {
    setPhoto(null);
    setPhotoPreview(null);
    if (fileRef.current) fileRef.current.value = '';
  }

  const isEmpty = !photo && !note.trim() && !place.trim();

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);

    if (isEmpty) {
      setError('Add at least one of a photo, note, or place before sharing.');
      return;
    }

    if (!memberName.trim()) {
      setError('Please enter your name so everyone knows who shared this moment.');
      return;
    }

    setSubmitting(true);

    try {
      let photoUrl: string | null = null;
      let photoPath: string | null = null;

      if (photo) {
        const ext = photo.name.split('.').pop() || 'jpg';
        photoPath = `moments/${tripId}/${Date.now()}-${Math.random().toString(36).slice(2, 8)}.${ext}`;
        const { error: uploadError } = await supabase.storage
          .from('moments')
          .upload(photoPath, photo, { contentType: photo.type });
        if (uploadError) throw new Error(uploadError.message);
        const { data: urlData } = supabase.storage.from('moments').getPublicUrl(photoPath);
        photoUrl = urlData.publicUrl;
      }

      const { error: insertError } = await supabase.from('moments').insert({
        trip_id: tripId,
        member_name: memberName.trim(),
        note: note.trim() || null,
        place: place.trim() || null,
        photo_url: photoUrl,
        photo_storage_path: photoPath,
      });

      if (insertError) throw new Error(insertError.message);

      setNote('');
      setPlace('');
      clearPhoto();
      onSaved();
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Something went wrong while saving your moment.';
      setError(`Could not save your moment — ${msg}. Your photo, note, and place are still here, so you can try again.`);
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <form
      onSubmit={handleSubmit}
      className="bg-white rounded-card shadow-card p-4 space-y-4 animate-slide-down"
    >
      <div className="flex items-center gap-2 mb-1">
        <h3 className="font-heading text-lg text-ink">Share a moment</h3>
        <span className="text-xs text-muted font-body">Add a photo, note, or place</span>
      </div>

      <input
        type="text"
        value={memberName}
        onChange={(e) => setMemberName(e.target.value)}
        placeholder="Your name"
        className="w-full px-3 py-2 rounded border border-line text-sm font-body focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary transition-colors"
      />

      <div className="flex gap-3">
        <div className="flex-shrink-0">
          {photoPreview ? (
            <div className="relative w-20 h-20 rounded-card overflow-hidden group">
              <img src={photoPreview} alt="Preview" className="w-full h-full object-cover" />
              <button
                type="button"
                onClick={clearPhoto}
                className="absolute top-0 right-0 bg-ink/60 text-white p-1 rounded-bl transition-opacity"
                aria-label="Remove photo"
              >
                <X size={14} />
              </button>
            </div>
          ) : (
            <button
              type="button"
              onClick={() => fileRef.current?.click()}
              className="w-20 h-20 rounded-card border-2 border-dashed border-line flex items-center justify-center text-muted hover:border-primary hover:text-primary transition-colors"
            >
              <Camera size={22} />
            </button>
          )}
          <input
            ref={fileRef}
            type="file"
            accept="image/*"
            onChange={handlePhotoSelect}
            className="hidden"
          />
        </div>

        <div className="flex-1 space-y-2">
          <textarea
            value={note}
            onChange={(e) => setNote(e.target.value)}
            placeholder="Write a short note..."
            rows={3}
            className="w-full px-3 py-2 rounded border border-line text-sm font-body resize-none focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary transition-colors"
          />
          <div className="relative">
            <MapPin
              size={15}
              className="absolute left-3 top-1/2 -translate-y-1/2 text-muted pointer-events-none"
            />
            <input
              type="text"
              value={place}
              onChange={(e) => setPlace(e.target.value)}
              placeholder="Add a place"
              className="w-full pl-9 pr-3 py-2 rounded border border-line text-sm font-body focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary transition-colors"
            />
          </div>
        </div>
      </div>

      {error && (
        <div className="flex items-start gap-2 p-3 rounded bg-red-50 border border-red-200 animate-fade-in">
          <AlertCircle size={16} className="flex-shrink-0 text-red-600 mt-0.5" />
          <p className="text-sm text-red-800 font-body">{error}</p>
        </div>
      )}

      <div className="flex items-center justify-between">
        <span className="text-xs text-muted font-body">
          {photo || note.trim() || place.trim()
            ? 'Ready to share'
            : 'Add at least one thing to share'}
        </span>
        <button
          type="submit"
          disabled={submitting || isEmpty}
          className="inline-flex items-center gap-2 px-5 py-2 rounded bg-primary text-white text-sm font-body font-medium hover:bg-primary-dark transition-colors disabled:opacity-40 disabled:cursor-not-allowed shadow-pop"
        >
          {submitting ? (
            <>
              <Loader2 size={16} className="animate-spin" />
              Saving...
            </>
          ) : (
            <>
              <Send size={15} />
              Share
            </>
          )}
        </button>
      </div>
    </form>
  );
}
