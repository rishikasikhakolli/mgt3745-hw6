import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
  },
});

export type Trip = {
  id: string;
  title: string;
  description: string | null;
  owner_id: string;
  created_at: string;
};

export type Moment = {
  id: string;
  trip_id: string;
  author_id: string;
  author_name: string;
  photo_url: string | null;
  note: string | null;
  place: string | null;
  created_at: string;
};

export type TripMember = {
  id: string;
  trip_id: string;
  user_id: string;
  created_at: string;
};
