export interface Trip {
  id: string;
  title: string;
  destination: string | null;
  start_date: string | null;
  end_date: string | null;
  created_at: string;
}

export interface Moment {
  id: string;
  trip_id: string;
  member_name: string;
  note: string | null;
  place: string | null;
  photo_url: string | null;
  photo_storage_path: string | null;
  created_at: string;
}

export interface NewMomentInput {
  member_name: string;
  note: string;
  place: string;
  photo: File | null;
}
