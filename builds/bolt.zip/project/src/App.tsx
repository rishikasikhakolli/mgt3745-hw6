import { useCallback, useEffect, useState } from 'react';
import { Compass, Loader2, MessageCircle } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import type { Trip, Moment } from '@/lib/types';
import TripHeader from '@/components/TripHeader';
import MomentCard from '@/components/MomentCard';
import AddMomentForm from '@/components/AddMomentForm';

export default function App() {
  const [trip, setTrip] = useState<Trip | null>(null);
  const [moments, setMoments] = useState<Moment[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);

  useEffect(() => {
    async function load() {
      const { data: tripData, error: tripError } = await supabase
        .from('trips')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(1)
        .maybeSingle();

      if (tripError || !tripData) {
        setLoading(false);
        return;
      }
      setTrip(tripData);

      const { data: momentData } = await supabase
        .from('moments')
        .select('*')
        .eq('trip_id', tripData.id)
        .order('created_at', { ascending: true });

      setMoments(momentData || []);
      setLoading(false);
    }
    load();
  }, []);

  const refreshMoments = useCallback(async () => {
    if (!trip) return;
    const { data } = await supabase
      .from('moments')
      .select('*')
      .eq('trip_id', trip.id)
      .order('created_at', { ascending: true });
    setMoments(data || []);
    setShowForm(false);
  }, [trip]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 size={28} className="animate-spin text-primary" />
      </div>
    );
  }

  if (!trip) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center gap-3 text-muted">
        <Compass size={32} />
        <p className="font-body text-sm">No trip found.</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-surface">
      <TripHeader
        trip={trip}
        momentCount={moments.length}
        onAddClick={() => setShowForm((s) => !s)}
        isAdding={showForm}
      />

      <main className="max-w-feed mx-auto px-4 py-6 space-y-4">
        {showForm && (
          <AddMomentForm tripId={trip.id} onSaved={refreshMoments} />
        )}

        {moments.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-16 gap-3 text-muted">
            <MessageCircle size={36} className="opacity-30" />
            <p className="font-body text-sm text-center">
              No moments yet. Share the first one!
            </p>
          </div>
        ) : (
          [...moments].reverse().map((m) => <MomentCard key={m.id} moment={m} />)
        )}
      </main>
    </div>
  );
}
