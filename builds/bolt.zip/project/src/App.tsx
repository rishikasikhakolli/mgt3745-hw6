import { useState } from 'react';
import { AuthProvider, useAuth } from '@/lib/auth';
import AuthScreen from '@/components/AuthScreen';
import TripList from '@/components/TripList';
import TripDetail from '@/components/TripDetail';

function AppContent() {
  const { user, loading } = useAuth();
  const [openTripId, setOpenTripId] = useState<string | null>(null);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-white">
        <div className="w-8 h-8 rounded-full border-2 animate-spin" style={{ borderColor: '#DD2A7B', borderTopColor: 'transparent' }} />
      </div>
    );
  }

  if (!user) {
    return <AuthScreen />;
  }

  if (openTripId) {
    return <TripDetail tripId={openTripId} onBack={() => setOpenTripId(null)} />;
  }

  return <TripList onOpenTrip={setOpenTripId} />;
}

export default function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}
