/*
# Create trips, trip_members, and moments tables

This migration sets up the core data model for a trip-sharing app where members
can create trips and add "moments" (photo, note, place) to them.

1. New Tables

- `trips`
  - `id` (uuid, primary key)
  - `title` (text, not null) — name of the trip
  - `description` (text, nullable) — optional short description
  - `owner_id` (uuid, not null, defaults to auth.uid()) — the member who created the trip
  - `created_at` (timestamptz, defaults to now())

- `trip_members`
  - `id` (uuid, primary key)
  - `trip_id` (uuid, references trips, on delete cascade)
  - `user_id` (uuid, not null, defaults to auth.uid()) — the member
  - `created_at` (timestamptz, defaults to now())
  - Unique constraint on (trip_id, user_id) to prevent duplicate memberships

- `moments`
  - `id` (uuid, primary key)
  - `trip_id` (uuid, references trips, on delete cascade) — which trip this moment belongs to
  - `author_id` (uuid, not null, defaults to auth.uid()) — the member who added the moment
  - `author_name` (text, not null) — denormalized member display name, shown on each moment
  - `photo_url` (text, nullable) — path to uploaded photo in storage
  - `note` (text, nullable) — short story or caption
  - `place` (text, nullable) — name of a place the member loved
  - `created_at` (timestamptz, defaults to now())

2. Storage

- Creates a public bucket `moment-photos` for storing uploaded photos.

3. Security

- RLS enabled on `trips`, `trip_members`, and `moments`.
- Trips: owner can CRUD; trip members can SELECT.
- Trip members: trip owner can insert/delete; members can SELECT.
- Moments: trip members can SELECT; trip members can INSERT moments.
- Storage bucket `moment-photos` is public for reads; authenticated users can upload to their own folder.

4. Notes

- The app uses email/password auth. Each user has a display name stored in raw_user_meta_data.
- Moments store `author_name` (denormalized) so we always have a display name even if the auth profile changes.
- At least one of photo_url, note, or place must be non-null — enforced in the application layer.
*/

-- ============================================================
-- Create all tables first (before policies that reference them)
-- ============================================================
CREATE TABLE IF NOT EXISTS trips (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  description text,
  owner_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS trip_members (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  trip_id uuid NOT NULL REFERENCES trips(id) ON DELETE CASCADE,
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(trip_id, user_id)
);

CREATE TABLE IF NOT EXISTS moments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  trip_id uuid NOT NULL REFERENCES trips(id) ON DELETE CASCADE,
  author_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  author_name text NOT NULL,
  photo_url text,
  note text,
  place text,
  created_at timestamptz NOT NULL DEFAULT now()
);

-- ============================================================
-- Enable RLS
-- ============================================================
ALTER TABLE trips ENABLE ROW LEVEL SECURITY;
ALTER TABLE trip_members ENABLE ROW LEVEL SECURITY;
ALTER TABLE moments ENABLE ROW LEVEL SECURITY;

-- ============================================================
-- Trip policies
-- ============================================================
DROP POLICY IF EXISTS "select_trips" ON trips;
CREATE POLICY "select_trips"
ON trips FOR SELECT
TO authenticated
USING (
  auth.uid() = owner_id
  OR EXISTS (
    SELECT 1 FROM trip_members
    WHERE trip_members.trip_id = trips.id
    AND trip_members.user_id = auth.uid()
  )
);

DROP POLICY IF EXISTS "insert_trips" ON trips;
CREATE POLICY "insert_trips"
ON trips FOR INSERT
TO authenticated
WITH CHECK (auth.uid() = owner_id);

DROP POLICY IF EXISTS "update_trips" ON trips;
CREATE POLICY "update_trips"
ON trips FOR UPDATE
TO authenticated
USING (auth.uid() = owner_id)
WITH CHECK (auth.uid() = owner_id);

DROP POLICY IF EXISTS "delete_trips" ON trips;
CREATE POLICY "delete_trips"
ON trips FOR DELETE
TO authenticated
USING (auth.uid() = owner_id);

-- ============================================================
-- Trip members policies
-- ============================================================
DROP POLICY IF EXISTS "select_trip_members" ON trip_members;
CREATE POLICY "select_trip_members"
ON trip_members FOR SELECT
TO authenticated
USING (
  EXISTS (SELECT 1 FROM trips WHERE trips.id = trip_members.trip_id AND trips.owner_id = auth.uid())
  OR trip_members.user_id = auth.uid()
  OR EXISTS (
    SELECT 1 FROM trip_members tm2
    WHERE tm2.trip_id = trip_members.trip_id AND tm2.user_id = auth.uid()
  )
);

DROP POLICY IF EXISTS "insert_trip_members" ON trip_members;
CREATE POLICY "insert_trip_members"
ON trip_members FOR INSERT
TO authenticated
WITH CHECK (
  EXISTS (SELECT 1 FROM trips WHERE trips.id = trip_members.trip_id AND trips.owner_id = auth.uid())
  OR trip_members.user_id = auth.uid()
);

DROP POLICY IF EXISTS "delete_trip_members" ON trip_members;
CREATE POLICY "delete_trip_members"
ON trip_members FOR DELETE
TO authenticated
USING (
  EXISTS (SELECT 1 FROM trips WHERE trips.id = trip_members.trip_id AND trips.owner_id = auth.uid())
  OR trip_members.user_id = auth.uid()
);

-- ============================================================
-- Moments policies
-- ============================================================
DROP POLICY IF EXISTS "select_moments" ON moments;
CREATE POLICY "select_moments"
ON moments FOR SELECT
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM trips
    WHERE trips.id = moments.trip_id
    AND (
      trips.owner_id = auth.uid()
      OR EXISTS (
        SELECT 1 FROM trip_members
        WHERE trip_members.trip_id = trips.id
        AND trip_members.user_id = auth.uid()
      )
    )
  )
);

DROP POLICY IF EXISTS "insert_moments" ON moments;
CREATE POLICY "insert_moments"
ON moments FOR INSERT
TO authenticated
WITH CHECK (
  auth.uid() = author_id
  AND EXISTS (
    SELECT 1 FROM trips
    WHERE trips.id = moments.trip_id
    AND (
      trips.owner_id = auth.uid()
      OR EXISTS (
        SELECT 1 FROM trip_members
        WHERE trip_members.trip_id = trips.id
        AND trip_members.user_id = auth.uid()
      )
    )
  )
);

DROP POLICY IF EXISTS "delete_moments" ON moments;
CREATE POLICY "delete_moments"
ON moments FOR DELETE
TO authenticated
USING (auth.uid() = author_id);

-- ============================================================
-- Indexes
-- ============================================================
CREATE INDEX IF NOT EXISTS idx_trips_owner ON trips(owner_id);
CREATE INDEX IF NOT EXISTS idx_trip_members_trip ON trip_members(trip_id);
CREATE INDEX IF NOT EXISTS idx_trip_members_user ON trip_members(user_id);
CREATE INDEX IF NOT EXISTS idx_moments_trip ON moments(trip_id);
CREATE INDEX IF NOT EXISTS idx_moments_created ON moments(trip_id, created_at DESC);

-- ============================================================
-- Storage bucket for moment photos
-- ============================================================
INSERT INTO storage.buckets (id, name, public)
VALUES ('moment-photos', 'moment-photos', true)
ON CONFLICT (id) DO NOTHING;

DROP POLICY IF EXISTS "read_moment_photos" ON storage.objects;
CREATE POLICY "read_moment_photos"
ON storage.objects FOR SELECT
TO public
USING (bucket_id = 'moment-photos');

DROP POLICY IF EXISTS "insert_moment_photos" ON storage.objects;
CREATE POLICY "insert_moment_photos"
ON storage.objects FOR INSERT
TO authenticated
WITH CHECK (bucket_id = 'moment-photos');

DROP POLICY IF EXISTS "delete_moment_photos" ON storage.objects;
CREATE POLICY "delete_moment_photos"
ON storage.objects FOR DELETE
TO authenticated
USING (bucket_id = 'moment-photos' AND owner = auth.uid());