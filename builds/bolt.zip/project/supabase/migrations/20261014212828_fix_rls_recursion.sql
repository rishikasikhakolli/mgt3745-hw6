/*
# Fix infinite recursion in RLS policies

The trips SELECT policy referenced trip_members, and the trip_members SELECT
policy referenced trips — both tables have RLS enabled, causing infinite
recursion and a 500 error on every query.

1. Changes
- Create a SECURITY DEFINER function `can_access_trip(trip_uuid)` that checks
  whether the current user is the trip owner or a trip member, bypassing RLS.
- Rewrite all SELECT, INSERT, and DELETE policies on trips, trip_members, and
  moments to use this function instead of cross-referencing each other.
- This breaks the recursion because the function runs with owner privileges
  and does not go through RLS.

2. Security
- The function is SECURITY DEFINER but only performs read-only SELECTs.
- It returns a boolean — no data is exposed.
*/

-- ============================================================
-- Helper function: check trip access (SECURITY DEFINER to bypass RLS)
-- ============================================================
CREATE OR REPLACE FUNCTION can_access_trip(trip_uuid uuid)
RETURNS boolean
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT
    EXISTS(SELECT 1 FROM trips WHERE id = trip_uuid AND owner_id = auth.uid())
    OR
    EXISTS(SELECT 1 FROM trip_members WHERE trip_id = trip_uuid AND user_id = auth.uid());
$$;

-- ============================================================
-- Rewrite trips policies
-- ============================================================
DROP POLICY IF EXISTS "select_trips" ON trips;
CREATE POLICY "select_trips"
ON trips FOR SELECT
TO authenticated
USING (can_access_trip(id));

DROP POLICY IF EXISTS "insert_trips" ON trips;
CREATE POLICY "insert_trips"
ON trips FOR INSERT
TO authenticated
WITH CHECK (auth.uid() = owner_id);

DROP POLICY IF EXISTS "update_trips" ON trips;
CREATE POLICY "update_trips"
ON trips FOR UPDATE
TO authenticated
USING (auth.uid() = owner_id)
WITH CHECK (auth.uid() = owner_id);

DROP POLICY IF EXISTS "delete_trips" ON trips;
CREATE POLICY "delete_trips"
ON trips FOR DELETE
TO authenticated
USING (auth.uid() = owner_id);

-- ============================================================
-- Rewrite trip_members policies
-- ============================================================
DROP POLICY IF EXISTS "select_trip_members" ON trip_members;
CREATE POLICY "select_trip_members"
ON trip_members FOR SELECT
TO authenticated
USING (can_access_trip(trip_id));

DROP POLICY IF EXISTS "insert_trip_members" ON trip_members;
CREATE POLICY "insert_trip_members"
ON trip_members FOR INSERT
TO authenticated
WITH CHECK (
  EXISTS (SELECT 1 FROM trips WHERE trips.id = trip_members.trip_id AND trips.owner_id = auth.uid())
  OR trip_members.user_id = auth.uid()
);

DROP POLICY IF EXISTS "delete_trip_members" ON trip_members;
CREATE POLICY "delete_trip_members"
ON trip_members FOR DELETE
TO authenticated
USING (
  EXISTS (SELECT 1 FROM trips WHERE trips.id = trip_members.trip_id AND trips.owner_id = auth.uid())
  OR trip_members.user_id = auth.uid()
);

-- ============================================================
-- Rewrite moments policies
-- ============================================================
DROP POLICY IF EXISTS "select_moments" ON moments;
CREATE POLICY "select_moments"
ON moments FOR SELECT
TO authenticated
USING (can_access_trip(trip_id));

DROP POLICY IF EXISTS "insert_moments" ON moments;
CREATE POLICY "insert_moments"
ON moments FOR INSERT
TO authenticated
WITH CHECK (
  auth.uid() = author_id
  AND can_access_trip(trip_id)
);

DROP POLICY IF EXISTS "delete_moments" ON moments;
CREATE POLICY "delete_moments"
ON moments FOR DELETE
TO authenticated
USING (auth.uid() = author_id);