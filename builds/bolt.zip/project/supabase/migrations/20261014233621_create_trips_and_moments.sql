/*
# Create trips and moments tables (single-tenant, no auth)

1. New Tables
- `trips` — a shared trip that members add moments to.
  - `id` (uuid, primary key)
  - `title` (text, not null)
  - `destination` (text, nullable)
  - `start_date` (date, nullable)
  - `end_date` (date, nullable)
  - `created_at` (timestamptz, default now())
- `moments` — individual moments (photo, note, place) added by members to a trip.
  - `id` (uuid, primary key)
  - `trip_id` (uuid, foreign key to trips, cascade delete)
  - `member_name` (text, not null) — who added the moment
  - `note` (text, nullable) — short story or caption
  - `place` (text, nullable) — name of a place
  - `photo_url` (text, nullable) — public URL of uploaded photo in storage
  - `photo_storage_path` (text, nullable) — storage path for cleanup
  - `created_at` (timestamptz, default now())

2. Security
- Enable RLS on both tables.
- Allow anon + authenticated CRUD because the data is intentionally shared (no-auth app).

3. Notes
- This is a no-auth demo app, so all data is publicly shared among trip members.
- member_name is a free-text field so anyone can add a moment under any name.
*/

CREATE TABLE IF NOT EXISTS trips (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  destination text,
  start_date date,
  end_date date,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE trips ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_trips" ON trips;
CREATE POLICY "anon_select_trips" ON trips FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_trips" ON trips;
CREATE POLICY "anon_insert_trips" ON trips FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_trips" ON trips;
CREATE POLICY "anon_update_trips" ON trips FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_trips" ON trips;
CREATE POLICY "anon_delete_trips" ON trips FOR DELETE
  TO anon, authenticated USING (true);

CREATE TABLE IF NOT EXISTS moments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  trip_id uuid NOT NULL REFERENCES trips(id) ON DELETE CASCADE,
  member_name text NOT NULL,
  note text,
  place text,
  photo_url text,
  photo_storage_path text,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE moments ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_moments" ON moments;
CREATE POLICY "anon_select_moments" ON moments FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_moments" ON moments;
CREATE POLICY "anon_insert_moments" ON moments FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_moments" ON moments;
CREATE POLICY "anon_update_moments" ON moments FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_moments" ON moments;
CREATE POLICY "anon_delete_moments" ON moments FOR DELETE
  TO anon, authenticated USING (true);

CREATE INDEX IF NOT EXISTS idx_moments_trip_id ON moments(trip_id);
CREATE INDEX IF NOT EXISTS idx_moments_created_at ON moments(created_at DESC);
