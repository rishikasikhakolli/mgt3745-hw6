/*
# Storage policies for moments bucket

1. Storage
- `moments` bucket is public (created separately via execute_sql).
- Allow anon + authenticated to upload, read, update, delete objects.
- This is a no-auth demo app, so storage is intentionally open.

2. Notes
- The bucket itself was created via execute_sql because bucket creation is not DDL.
- These policies apply to the storage.objects table filtered by bucket.
*/

DROP POLICY IF EXISTS "anon_upload_moments" ON storage.objects;
CREATE POLICY "anon_upload_moments" ON storage.objects FOR INSERT
  TO anon, authenticated
  WITH CHECK (bucket_id = 'moments');

DROP POLICY IF EXISTS "anon_read_moments" ON storage.objects;
CREATE POLICY "anon_read_moments" ON storage.objects FOR SELECT
  TO anon, authenticated
  USING (bucket_id = 'moments');

DROP POLICY IF EXISTS "anon_update_moments" ON storage.objects;
CREATE POLICY "anon_update_moments" ON storage.objects FOR UPDATE
  TO anon, authenticated
  USING (bucket_id = 'moments') WITH CHECK (bucket_id = 'moments');

DROP POLICY IF EXISTS "anon_delete_moments" ON storage.objects;
CREATE POLICY "anon_delete_moments" ON storage.objects FOR DELETE
  TO anon, authenticated
  USING (bucket_id = 'moments');