import React, { useState, useEffect } from 'react';
import { 
  Plus, 
  MapPin, 
  Bookmark, 
  Calendar, 
  Users, 
  Camera, 
  Filter, 
  Sparkles,
  Share2,
  CheckCircle2,
  AlertTriangle,
  RotateCcw
} from 'lucide-react';
import { Trip, TripMember, TripMoment } from './types';
import { TRIP_MEMBERS, INITIAL_TRIP, INITIAL_MOMENTS } from './data/initialData';
import { MomentCard } from './components/MomentCard';
import { AddMomentModal } from './components/AddMomentModal';
import { SavedPlacesModal } from './components/SavedPlacesModal';
import { TestingGuide } from './components/TestingGuide';

const STORAGE_KEY_MOMENTS = 'tripmoments_japan_2026';
const STORAGE_KEY_SAVED_PLACES = 'tripmoments_saved_places_2026';

export default function App() {
  // Members & Current active user
  const [members] = useState<TripMember[]>(TRIP_MEMBERS);
  const [currentMemberId, setCurrentMemberId] = useState<string>('rishika');

  // Trip Moments state (persisted to localStorage)
  const [moments, setMoments] = useState<TripMoment[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_MOMENTS);
      if (saved) {
        return JSON.parse(saved);
      }
    } catch {
      // Fallback
    }
    return INITIAL_MOMENTS;
  });

  // Saved Places (for Semaj's profile - discovering & saving trusted spots)
  const [savedPlaces, setSavedPlaces] = useState<Array<{
    placeName: string;
    address?: string;
    category?: string;
    recommendedBy: string;
    recommendedByAvatar: string;
    note?: string;
    photoUrl?: string;
    momentId: string;
  }>>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_SAVED_PLACES);
      if (saved) {
        return JSON.parse(saved);
      }
    } catch {
      // Fallback
    }
    // Default initial saved place
    return [
      {
        placeName: 'Omoide Yokocho (Memory Lane)',
        address: '1 Chome-2 Nishishinjuku, Shinjuku City, Tokyo',
        category: 'Food & Nightlife',
        recommendedBy: 'Elena Rostova',
        recommendedByAvatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=200&h=200&q=80',
        note: 'Found this tiny 6-seat yakitori stall tucked behind the smoke and red lanterns. Master chef has grilled chicken thigh skewers with coarse salt here for 42 years.',
        photoUrl: 'https://images.unsplash.com/photo-1542051841857-5f90071e7989?auto=format&fit=crop&w=900&q=80',
        momentId: 'moment-1'
      }
    ];
  });

  // Filters
  const [selectedMemberFilter, setSelectedMemberFilter] = useState<string>('all');
  const [contentTypeFilter, setContentTypeFilter] = useState<'all' | 'photos' | 'places' | 'notes'>('all');

  // Modals state
  const [isAddModalOpen, setIsAddModalOpen] = useState<boolean>(false);
  const [isSavedPlacesModalOpen, setIsSavedPlacesModalOpen] = useState<boolean>(false);
  const [addModalInitialConfig, setAddModalInitialConfig] = useState<{
    photoUrl?: string;
    note?: string;
    placeName?: string;
    simulateFailure?: boolean;
    triggerRefusalImmediately?: boolean;
  } | undefined>(undefined);

  // Toast feedback
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Sync moments to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_MOMENTS, JSON.stringify(moments));
    } catch (e) {
      console.error('Failed to sync moments to localStorage', e);
    }
  }, [moments]);

  // Sync saved places to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_SAVED_PLACES, JSON.stringify(savedPlaces));
    } catch (e) {
      console.error('Failed to sync saved places to localStorage', e);
    }
  }, [savedPlaces]);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage((prev) => (prev === msg ? null : prev));
    }, 4000);
  };

  const currentMember = members.find((m) => m.id === currentMemberId) || members[0];

  // Handler for adding a moment (Acceptance Criterion 1)
  const handleAddMoment = async (
    momentData: Omit<TripMoment, 'id' | 'timestamp' | 'reactions'>
  ): Promise<boolean> => {
    // Artificial small delay for realistic UX
    await new Promise((resolve) => setTimeout(resolve, 350));

    const newMoment: TripMoment = {
      ...momentData,
      id: `moment-${Date.now()}`,
      timestamp: new Date().toISOString(),
      reactions: {}
    };

    setMoments((prev) => [newMoment, ...prev]);

    const itemsSummary = [
      newMoment.photoUrl && 'photo',
      newMoment.note && 'note',
      newMoment.place && 'place'
    ]
      .filter(Boolean)
      .join(', ');

    showToast(`Added moment with ${itemsSummary} by ${newMoment.memberName}!`);
    return true;
  };

  // Handler for deleting a moment
  const handleDeleteMoment = (momentId: string) => {
    setMoments((prev) => prev.filter((m) => m.id !== momentId));
    showToast('Moment removed from trip.');
  };

  // Handler for reactions (User 1: Rishika / friends reacting casually)
  const handleReaction = (momentId: string, emoji: string) => {
    setMoments((prev) =>
      prev.map((m) => {
        if (m.id !== momentId) return m;
        const currentReactions = { ...m.reactions };
        const userList = currentReactions[emoji] || [];
        const hasReacted = userList.includes(currentMember.name);

        if (hasReacted) {
          // Remove reaction
          currentReactions[emoji] = userList.filter((name) => name !== currentMember.name);
          if (currentReactions[emoji].length === 0) {
            delete currentReactions[emoji];
          }
        } else {
          // Add reaction
          currentReactions[emoji] = [...userList, currentMember.name];
        }

        return { ...m, reactions: currentReactions };
      })
    );
  };

  // Handler for saving/bookmarking a place (User 3: Semaj)
  const handleToggleSavePlace = (placeName: string, moment: TripMoment) => {
    const isSaved = savedPlaces.some((p) => p.placeName === placeName);

    if (isSaved) {
      setSavedPlaces((prev) => prev.filter((p) => p.placeName !== placeName));
      showToast(`Removed "${placeName}" from your saved places.`);
    } else {
      const newSavedItem = {
        placeName,
        address: moment.place?.address,
        category: moment.place?.category,
        recommendedBy: moment.memberName,
        recommendedByAvatar: moment.memberAvatar,
        note: moment.note,
        photoUrl: moment.photoUrl,
        momentId: moment.id
      };
      setSavedPlaces((prev) => [newSavedItem, ...prev]);
      showToast(`Saved "${placeName}" to your places list!`);
    }
  };

  const handleRemoveSavedPlace = (placeName: string) => {
    setSavedPlaces((prev) => prev.filter((p) => p.placeName !== placeName));
    showToast(`Removed "${placeName}" from saved places.`);
  };

  // Reset to sample moments
  const handleResetData = () => {
    if (window.confirm('Reset trip back to sample moments?')) {
      setMoments(INITIAL_MOMENTS);
      showToast('Trip moments reset to original sample.');
    }
  };

  // Quick Open Modal with test config
  const handleOpenAddModalWithConfig = (config: {
    photo?: string;
    note?: string;
    place?: string;
    simulateFail?: boolean;
    autoSubmit?: boolean;
  }) => {
    setAddModalInitialConfig({
      photoUrl: config.photo,
      note: config.note,
      placeName: config.place,
      simulateFailure: config.simulateFail,
      triggerRefusalImmediately: config.autoSubmit && !config.photo && !config.note && !config.place
    });
    setIsAddModalOpen(true);
  };

  // Filter moments
  const filteredMoments = moments.filter((m) => {
    if (selectedMemberFilter !== 'all' && m.memberId !== selectedMemberFilter) {
      return false;
    }
    if (contentTypeFilter === 'photos' && !m.photoUrl) {
      return false;
    }
    if (contentTypeFilter === 'places' && !m.place) {
      return false;
    }
    if (contentTypeFilter === 'notes' && !m.note) {
      return false;
    }
    return true;
  });

  return (
    <div className="min-h-screen bg-[#FFFFFF] text-[#1A1A1A] font-body flex flex-col">
      
      {/* Toast Notification */}
      {toastMessage && (
        <div 
          className="fixed bottom-6 right-6 z-50 bg-[#1A1A1A] text-white px-4 py-3 rounded-[4px] shadow-xl flex items-center gap-3 border border-[#333333] max-w-md animate-fade-in text-[14px]"
          role="status"
        >
          <CheckCircle2 className="w-5 h-5 text-[#00C853] shrink-0" />
          <p className="flex-1">{toastMessage}</p>
          <button 
            onClick={() => setToastMessage(null)}
            className="text-[#999999] hover:text-white text-[14px] ml-2"
          >
            ✕
          </button>
        </div>
      )}

      {/* Top Navigation Bar */}
      <header className="sticky top-0 z-40 bg-[#FFFFFF] border-b border-[#E5E5E5] px-4 py-3">
        <div className="max-w-4xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            {/* Instagram-inspired primary badge */}
            <div className="w-9 h-9 rounded-[4px] bg-[#DD2A7B] text-white flex items-center justify-center font-bold text-[18px]">
              T
            </div>
            <div>
              <span className="font-heading font-bold text-[18px] text-[#1A1A1A] leading-tight block">
                TripMoments
              </span>
              <span className="text-[14px] text-[#666666] block leading-tight">
                Tokyo & Kyoto Shared Journal
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Semaj Saved Places Button */}
            <button
              onClick={() => setIsSavedPlacesModalOpen(true)}
              className="flex items-center gap-1.5 px-3 py-2 border border-[#E5E5E5] hover:border-[#00C853] rounded-[4px] text-[14px] text-[#1A1A1A] hover:bg-[#F9F9F9] transition cursor-pointer"
              title="View bookmarked spots from friends"
            >
              <Bookmark className="w-4 h-4 text-[#00C853] fill-current" />
              <span className="hidden sm:inline">Saved Spots</span>
              <span className="bg-[#00C853]/15 text-[#00C853] text-[14px] font-bold px-1.5 py-0.2 rounded-[4px]">
                {savedPlaces.length}
              </span>
            </button>

            {/* Primary Action Button: Add a Moment */}
            <button
              onClick={() => {
                setAddModalInitialConfig(undefined);
                setIsAddModalOpen(true);
              }}
              className="flex items-center gap-2 px-4 py-2 bg-[#DD2A7B] hover:bg-[#C9226E] text-[#FFFFFF] rounded-[4px] text-[14px] font-medium transition cursor-pointer shadow-sm"
            >
              <Plus className="w-4 h-4" />
              <span>Add Moment</span>
            </button>
          </div>
        </div>
      </header>

      {/* Interactive Acceptance Criteria Verification Bar */}
      <TestingGuide
        onOpenAddModalWithConfig={handleOpenAddModalWithConfig}
        onOpenAddModal={() => {
          setAddModalInitialConfig(undefined);
          setIsAddModalOpen(true);
        }}
      />

      {/* Main Content Area */}
      <main className="max-w-4xl mx-auto px-4 w-full flex-1 pb-16">
        
        {/* Trip Header Banner */}
        <div className="bg-[#FFFFFF] border border-[#E5E5E5] rounded-[4px] overflow-hidden mb-6 shadow-2xs">
          <div className="relative h-44 sm:h-56 bg-black/10">
            <img
              src={INITIAL_TRIP.coverImage}
              alt={INITIAL_TRIP.title}
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/40 to-transparent flex flex-col justify-end p-6">
              <span className="text-[#00C853] font-semibold text-[14px] uppercase tracking-wider mb-1 flex items-center gap-1">
                <MapPin className="w-3.5 h-3.5" />
                {INITIAL_TRIP.destination}
              </span>
              <h1 className="font-heading text-[26px] sm:text-[32px] font-bold text-white leading-tight">
                {INITIAL_TRIP.title}
              </h1>
              <p className="text-white/90 text-[14px] mt-1 flex items-center gap-2">
                <Calendar className="w-4 h-4 text-white/80" />
                {INITIAL_TRIP.dates} • {moments.length} moments recorded
              </p>
            </div>
          </div>

          <div className="p-4 sm:p-5 bg-[#FFFFFF] border-t border-[#F0F0F0] flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            {/* Active User Switcher */}
            <div>
              <div className="text-[14px] text-[#666666] mb-1.5 font-medium flex items-center gap-1.5">
                <Users className="w-4 h-4 text-[#DD2A7B]" />
                You are currently posting & interacting as:
              </div>
              <div className="flex items-center gap-2 flex-wrap">
                {members.map((m) => (
                  <button
                    key={m.id}
                    onClick={() => setCurrentMemberId(m.id)}
                    className={`flex items-center gap-2 px-3 py-1.5 rounded-[4px] border text-[14px] transition cursor-pointer ${
                      currentMemberId === m.id
                        ? 'border-[#DD2A7B] bg-[#DD2A7B]/10 font-bold text-[#DD2A7B]'
                        : 'border-[#E5E5E5] bg-[#FFFFFF] hover:bg-[#F9F9F9] text-[#1A1A1A]'
                    }`}
                  >
                    <img
                      src={m.avatar}
                      alt={m.name}
                      className="w-5 h-5 rounded-full object-cover"
                    />
                    <span>{m.name}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Quick stats & Reset option */}
            <div className="flex items-center gap-3 shrink-0 self-end sm:self-auto">
              <button
                onClick={handleResetData}
                className="text-[14px] text-[#888888] hover:text-[#1A1A1A] flex items-center gap-1 p-1 hover:bg-[#F5F5F5] rounded-[4px] transition cursor-pointer"
                title="Reset sample data"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Reset Data</span>
              </button>
            </div>
          </div>
        </div>

        {/* Filter and Feed Bar */}
        <div className="bg-[#FAFAFA] border border-[#E5E5E5] rounded-[4px] p-3 mb-6 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-1 overflow-x-auto w-full sm:w-auto">
            <span className="text-[14px] text-[#666666] font-medium mr-2 flex items-center gap-1 shrink-0">
              <Filter className="w-3.5 h-3.5 text-[#DD2A7B]" /> Filter:
            </span>
            <button
              onClick={() => setSelectedMemberFilter('all')}
              className={`px-3 py-1 text-[14px] rounded-[4px] transition cursor-pointer shrink-0 ${
                selectedMemberFilter === 'all'
                  ? 'bg-[#1A1A1A] text-white font-medium'
                  : 'bg-[#FFFFFF] text-[#666666] hover:text-[#1A1A1A] border border-[#E5E5E5]'
              }`}
            >
              All Members
            </button>
            {members.map((m) => (
              <button
                key={m.id}
                onClick={() => setSelectedMemberFilter(m.id)}
                className={`px-3 py-1 text-[14px] rounded-[4px] transition cursor-pointer shrink-0 ${
                  selectedMemberFilter === m.id
                    ? 'bg-[#1A1A1A] text-white font-medium'
                    : 'bg-[#FFFFFF] text-[#666666] hover:text-[#1A1A1A] border border-[#E5E5E5]'
                }`}
              >
                {m.name}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-1 w-full sm:w-auto justify-end">
            <span className="text-[14px] text-[#666666] mr-1">Type:</span>
            {(['all', 'photos', 'places', 'notes'] as const).map((type) => (
              <button
                key={type}
                onClick={() => setContentTypeFilter(type)}
                className={`px-2.5 py-1 text-[14px] rounded-[4px] capitalize transition cursor-pointer ${
                  contentTypeFilter === type
                    ? 'bg-[#DD2A7B] text-white font-medium'
                    : 'bg-[#FFFFFF] text-[#666666] border border-[#E5E5E5] hover:bg-[#F5F5F5]'
                }`}
              >
                {type}
              </button>
            ))}
          </div>
        </div>

        {/* Moments Feed */}
        <section aria-label="Trip moments stream">
          {filteredMoments.length === 0 ? (
            <div className="text-center py-16 px-4 border-2 border-dashed border-[#E5E5E5] rounded-[4px] bg-[#FFFFFF]">
              <Camera className="w-12 h-12 text-[#CCCCCC] mx-auto mb-3" />
              <h2 className="font-heading text-[20px] font-bold text-[#1A1A1A]">
                No moments match the filter
              </h2>
              <p className="text-[14px] text-[#666666] mt-1 max-w-sm mx-auto">
                Try switching the filters above, or add a new moment to document something from the trip.
              </p>
              <button
                onClick={() => {
                  setSelectedMemberFilter('all');
                  setContentTypeFilter('all');
                }}
                className="mt-4 px-4 py-2 border border-[#CCCCCC] rounded-[4px] text-[14px] hover:bg-[#F5F5F5] transition cursor-pointer"
              >
                Clear Filters
              </button>
            </div>
          ) : (
            <div className="space-y-6">
              {filteredMoments.map((moment) => (
                <MomentCard
                  key={moment.id}
                  moment={moment}
                  currentUserId={currentMember.id}
                  currentUserName={currentMember.name}
                  isPlaceSaved={
                    moment.place ? savedPlaces.some((p) => p.placeName === moment.place?.name) : false
                  }
                  onToggleSavePlace={handleToggleSavePlace}
                  onReaction={handleReaction}
                  onDeleteMoment={handleDeleteMoment}
                  onAddComment={(momentId, text) => {
                    setMoments((prev) =>
                      prev.map((m) => {
                        if (m.id !== momentId) return m;
                        const comments = m.comments || [];
                        return {
                          ...m,
                          comments: [
                            ...comments,
                            {
                              id: `comment-${Date.now()}`,
                              memberName: currentMember.name,
                              text,
                              timestamp: new Date().toISOString()
                            }
                          ]
                        };
                      })
                    );
                    showToast('Reply added.');
                  }}
                />
              ))}
            </div>
          )}
        </section>
      </main>

      {/* Add Moment Modal (Implements AC 1, AC 2, AC 3) */}
      <AddMomentModal
        isOpen={isAddModalOpen}
        onClose={() => setIsAddModalOpen(false)}
        onAddMoment={handleAddMoment}
        members={members}
        currentMemberId={currentMemberId}
        onSwitchMember={(id) => setCurrentMemberId(id)}
        initialValues={addModalInitialConfig}
      />

      {/* Saved Places Modal (For Semaj User 3) */}
      <SavedPlacesModal
        isOpen={isSavedPlacesModalOpen}
        onClose={() => setIsSavedPlacesModalOpen(false)}
        savedPlaces={savedPlaces}
        onRemovePlace={handleRemoveSavedPlace}
      />

      {/* Footer */}
      <footer className="border-t border-[#E5E5E5] bg-[#FFFFFF] py-6 text-center text-[14px] text-[#666666]">
        <div className="max-w-4xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-2">
          <span className="font-heading text-[#1A1A1A] font-bold">TripMoments</span>
          <span>Shared in-the-moment memories with your inner circle</span>
          <span className="text-[#888888]">Designed for casual travelers & curating friends</span>
        </div>
      </footer>
    </div>
  );
}
