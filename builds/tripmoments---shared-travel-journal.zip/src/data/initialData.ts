import { Trip, TripMember, TripMoment } from '../types';

export const TRIP_MEMBERS: TripMember[] = [
  {
    id: 'rishika',
    name: 'Rishika',
    handle: '@rishika',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&h=200&q=80',
    role: 'Trip Organizer',
    bio: 'Casual traveler, texting moments in real time to the crew.'
  },
  {
    id: 'elena',
    name: 'Elena Rostova',
    handle: '@elena_snaps',
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=200&h=200&q=80',
    role: 'Aesthetic Documenter',
    bio: 'Polished photography, finding culinary gems and coffee spots.'
  },
  {
    id: 'semaj',
    name: 'Semaj Cole',
    handle: '@semaj_c',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=200&h=200&q=80',
    role: 'Music & Culture Curator',
    bio: 'Trusts friends taste, digs for niche vinyl crates and record bars.'
  },
  {
    id: 'liam',
    name: 'Liam Vance',
    handle: '@liamvance',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=200&h=200&q=80',
    role: 'Casual Explorer',
    bio: 'No itinerary, just wanderlust and snack hunting.'
  }
];

export const INITIAL_TRIP: Trip = {
  id: 'trip-japan-2026',
  title: 'Autumn in Tokyo & Kyoto',
  dates: 'Oct 10 – Oct 18, 2026',
  destination: 'Tokyo & Kyoto, Japan',
  coverImage: 'https://images.unsplash.com/photo-1493976040374-85c8e12f0c0e?auto=format&fit=crop&w=1200&h=400&q=80',
  description: '7 days of ramen hunts, golden alleyways, temple gardens, and quiet vinyl listening bars with friends.',
  members: TRIP_MEMBERS
};

export const SAMPLE_PRESET_PHOTOS = [
  {
    label: 'Kyoto Bamboo Mist',
    url: 'https://images.unsplash.com/photo-1503899036084-c55cdd92da26?auto=format&fit=crop&w=900&q=80',
    place: 'Arashiyama Bamboo Grove, Kyoto',
    category: 'Scenic Nature'
  },
  {
    label: 'Hidden Izakaya Lanterns',
    url: 'https://images.unsplash.com/photo-1542051841857-5f90071e7989?auto=format&fit=crop&w=900&q=80',
    place: 'Omoide Yokocho, Shinjuku',
    category: 'Food & Nightlife'
  },
  {
    label: 'Matcha & Hand-whisked Tea',
    url: 'https://images.unsplash.com/photo-1576092768241-dec231879fc3?auto=format&fit=crop&w=900&q=80',
    place: 'Ippodo Tea Kyoto Main Store',
    category: 'Cafe & Tea'
  },
  {
    label: 'Sunset at Meguro Canal',
    url: 'https://images.unsplash.com/photo-1509042239860-f550ce710b93?auto=format&fit=crop&w=900&q=80',
    place: 'Nakameguro Canal, Tokyo',
    category: 'Walk & Neighborhood'
  },
  {
    label: 'Vintage Jazz Kissa',
    url: 'https://images.unsplash.com/photo-1511192336575-5a79af67a629?auto=format&fit=crop&w=900&q=80',
    place: 'Lion Cafe (Meikyoku Kissa), Shibuya',
    category: 'Music & Culture'
  }
];

export const INITIAL_MOMENTS: TripMoment[] = [
  {
    id: 'moment-1',
    tripId: 'trip-japan-2026',
    memberId: 'elena',
    memberName: 'Elena Rostova',
    memberAvatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=200&h=200&q=80',
    photoUrl: 'https://images.unsplash.com/photo-1542051841857-5f90071e7989?auto=format&fit=crop&w=900&q=80',
    place: {
      name: 'Omoide Yokocho (Memory Lane)',
      address: '1 Chome-2 Nishishinjuku, Shinjuku City, Tokyo',
      category: 'Food & Nightlife'
    },
    note: 'Found this tiny 6-seat yakitori stall tucked behind the smoke and red lanterns. Master chef has grilled chicken thigh skewers with coarse salt here for 42 years. Highly recommend ordering the tsukune and cold draft beer!',
    timestamp: '2026-10-14T09:30:00Z',
    dayNumber: 2,
    reactions: {
      '🔥': ['Rishika', 'Liam'],
      '❤️': ['Semaj']
    },
    savedBy: ['semaj']
  },
  {
    id: 'moment-2',
    tripId: 'trip-japan-2026',
    memberId: 'rishika',
    memberName: 'Rishika',
    memberAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&h=200&q=80',
    // Moment with JUST a note: valid per acceptance criteria!
    note: 'Lost our paper subway passes twice already today between Shibuya and Harajuku, but Liam spotted a platform vending machine serving piping-hot canned corn potage soup. Absolutely salvaged the afternoon chill 😂',
    timestamp: '2026-10-14T11:15:00Z',
    dayNumber: 2,
    reactions: {
      '😂': ['Elena Rostova', 'Liam Vance', 'Semaj Cole']
    }
  },
  {
    id: 'moment-3',
    tripId: 'trip-japan-2026',
    memberId: 'liam',
    memberName: 'Liam Vance',
    memberAvatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=200&h=200&q=80',
    // Moment with JUST a photo: valid per acceptance criteria!
    photoUrl: 'https://images.unsplash.com/photo-1503899036084-c55cdd92da26?auto=format&fit=crop&w=900&q=80',
    timestamp: '2026-10-14T12:05:00Z',
    dayNumber: 2,
    reactions: {
      '❤️': ['Elena Rostova', 'Rishika'],
      '📍': ['Semaj Cole']
    }
  },
  {
    id: 'moment-4',
    tripId: 'trip-japan-2026',
    memberId: 'semaj',
    memberName: 'Semaj Cole',
    memberAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=200&h=200&q=80',
    // Moment with Place + Note: valid per acceptance criteria!
    place: {
      name: 'Disk Union Jazz & Soul',
      address: 'Shinjuku 3-Chome 31-4, Tokyo',
      category: 'Record Store & Music'
    },
    note: 'For anyone who trusts my ears: 4th floor crate selection has pristine 1970s Japanese pressed Blue Note and Three Blind Mice records at half European prices. Definitely save this if you love vinyl.',
    timestamp: '2026-10-14T13:20:00Z',
    dayNumber: 2,
    reactions: {
      '👏': ['Rishika'],
      '🔥': ['Elena Rostova']
    },
    savedBy: ['rishika']
  }
];
