import React, { useState } from 'react';
import { CheckCircle2, ChevronDown, ChevronUp, AlertCircle, RefreshCw, PlusCircle, Info } from 'lucide-react';

interface TestingGuideProps {
  onOpenAddModalWithConfig?: (config: {
    photo?: string;
    note?: string;
    place?: string;
    simulateFail?: boolean;
    autoSubmit?: boolean;
  }) => void;
  onOpenAddModal: () => void;
}

export const TestingGuide: React.FC<TestingGuideProps> = ({
  onOpenAddModalWithConfig,
  onOpenAddModal
}) => {
  const [isOpen, setIsOpen] = useState(true);

  return (
    <div className="bg-[#FFFFFF] border-y border-[#E5E5E5] mb-6 shadow-2xs">
      <div className="max-w-4xl mx-auto px-4 py-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-[#00C853]"></span>
            <span className="font-heading font-bold text-[16px] text-[#1A1A1A]">
              Acceptance Criteria Test Suite
            </span>
            <span className="text-[14px] text-[#666666] hidden md:inline">
              (Feature F3: Add a moment to a trip)
            </span>
          </div>

          <button
            onClick={() => setIsOpen(!isOpen)}
            className="flex items-center gap-1 text-[14px] text-[#666666] hover:text-[#1A1A1A] py-1 px-2 rounded-[4px] hover:bg-[#F5F5F5] transition"
          >
            <span>{isOpen ? 'Collapse Guide' : 'Expand Guide'}</span>
            {isOpen ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
          </button>
        </div>

        {isOpen && (
          <div className="mt-3 pt-3 border-t border-[#F0F0F0] grid grid-cols-1 md:grid-cols-3 gap-3">
            {/* Criterion 1 */}
            <div className="p-3 bg-[#FAFAFA] border border-[#E5E5E5] rounded-[4px] flex flex-col justify-between">
              <div>
                <div className="flex items-center gap-1.5 font-bold text-[14px] text-[#1A1A1A] mb-1">
                  <CheckCircle2 className="w-4 h-4 text-[#00C853]" />
                  <span>Criterion 1: At least 1 item</span>
                </div>
                <p className="text-[14px] text-[#444444] leading-snug">
                  WHEN a member submits with photo, note, OR place, it is added to the trip labeled with their name.
                </p>
              </div>
              <div className="mt-3 pt-2 border-t border-[#EAEAEA] flex flex-wrap gap-1.5">
                <button
                  onClick={() =>
                    onOpenAddModalWithConfig?.({
                      note: 'Quick observation: Tokyo metro conductor white glove gesture is mesmerizing!'
                    })
                  }
                  className="text-[14px] bg-[#FFFFFF] border border-[#CCCCCC] hover:border-[#DD2A7B] text-[#1A1A1A] px-2 py-1 rounded-[4px] transition cursor-pointer"
                >
                  Test: Note Only
                </button>
                <button
                  onClick={() =>
                    onOpenAddModalWithConfig?.({
                      photo: 'https://images.unsplash.com/photo-1509042239860-f550ce710b93?auto=format&fit=crop&w=900&q=80'
                    })
                  }
                  className="text-[14px] bg-[#FFFFFF] border border-[#CCCCCC] hover:border-[#DD2A7B] text-[#1A1A1A] px-2 py-1 rounded-[4px] transition cursor-pointer"
                >
                  Test: Photo Only
                </button>
                <button
                  onClick={() =>
                    onOpenAddModalWithConfig?.({
                      place: 'Lion Cafe (Meikyoku Kissa)'
                    })
                  }
                  className="text-[14px] bg-[#FFFFFF] border border-[#CCCCCC] hover:border-[#DD2A7B] text-[#1A1A1A] px-2 py-1 rounded-[4px] transition cursor-pointer"
                >
                  Test: Place Only
                </button>
              </div>
            </div>

            {/* Criterion 2 */}
            <div className="p-3 bg-[#FAFAFA] border border-[#E5E5E5] rounded-[4px] flex flex-col justify-between">
              <div>
                <div className="flex items-center gap-1.5 font-bold text-[14px] text-[#1A1A1A] mb-1">
                  <RefreshCw className="w-4 h-4 text-[#F57C00]" />
                  <span>Criterion 2: Failed save retry</span>
                </div>
                <p className="text-[14px] text-[#444444] leading-snug">
                  IF save fails, app tells member and keeps photo, note, and place on screen so they can try again.
                </p>
              </div>
              <div className="mt-3 pt-2 border-t border-[#EAEAEA]">
                <button
                  onClick={() =>
                    onOpenAddModalWithConfig?.({
                      photo: 'https://images.unsplash.com/photo-1511192336575-5a79af67a629?auto=format&fit=crop&w=900&q=80',
                      note: 'Cozy jazz kissa with massive hand-built horn speakers.',
                      place: 'Lion Cafe Shibuya',
                      simulateFail: true
                    })
                  }
                  className="w-full text-center text-[14px] bg-[#FFF8E1] border border-[#FFE082] text-[#F57C00] font-medium px-2 py-1.5 rounded-[4px] hover:bg-[#FFE082] transition cursor-pointer"
                >
                  Test: Simulate Failure & Retain Inputs
                </button>
              </div>
            </div>

            {/* Criterion 3 */}
            <div className="p-3 bg-[#FAFAFA] border border-[#E5E5E5] rounded-[4px] flex flex-col justify-between">
              <div>
                <div className="flex items-center gap-1.5 font-bold text-[14px] text-[#1A1A1A] mb-1">
                  <AlertCircle className="w-4 h-4 text-[#DD2A7B]" />
                  <span>Criterion 3: Refuse empty</span>
                </div>
                <p className="text-[14px] text-[#444444] leading-snug">
                  IF submitted with no photo, note, or place, the app shall refuse and add nothing.
                </p>
              </div>
              <div className="mt-3 pt-2 border-t border-[#EAEAEA]">
                <button
                  onClick={() =>
                    onOpenAddModalWithConfig?.({
                      photo: '',
                      note: '',
                      place: '',
                      autoSubmit: true
                    })
                  }
                  className="w-full text-center text-[14px] bg-[#FFF0F2] border border-[#FFCCD3] text-[#DD2A7B] font-medium px-2 py-1.5 rounded-[4px] hover:bg-[#FFCCD3] transition cursor-pointer"
                >
                  Test: Refuse Empty Submission
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
