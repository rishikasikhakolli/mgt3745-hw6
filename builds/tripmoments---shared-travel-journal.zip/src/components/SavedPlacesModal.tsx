import React from 'react';
import { X, MapPin, Bookmark, ExternalLink, Sparkles } from 'lucide-react';
import { TripMoment } from '../types';

interface SavedPlaceItem {
  placeName: string;
  address?: string;
  category?: string;
  recommendedBy: string;
  recommendedByAvatar: string;
  note?: string;
  photoUrl?: string;
  momentId: string;
}

interface SavedPlacesModalProps {
  isOpen: boolean;
  onClose: () => void;
  savedPlaces: SavedPlaceItem[];
  onRemovePlace: (placeName: string) => void;
}

export const SavedPlacesModal: React.FC<SavedPlacesModalProps> = ({
  isOpen,
  onClose,
  savedPlaces,
  onRemovePlace
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 overflow-y-auto">
      <div 
        className="bg-[#FFFFFF] text-[#1A1A1A] w-full max-w-2xl rounded-[4px] shadow-2xl border border-[#E5E5E5] my-8 overflow-hidden flex flex-col"
        role="dialog"
        aria-modal="true"
        aria-labelledby="saved-places-title"
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-[#E5E5E5] bg-[#FFFFFF]">
          <div className="flex items-center gap-2">
            <span className="p-1 rounded-[4px] bg-[#00C853]/15 text-[#00C853]">
              <Bookmark className="w-5 h-5 fill-current" />
            </span>
            <div>
              <h2 id="saved-places-title" className="font-heading text-[20px] font-bold text-[#1A1A1A]">
                Saved Trip Spots
              </h2>
              <p className="text-[14px] text-[#666666]">
                Places you bookmarked from trusted friends for your next adventure
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-[#666666] hover:text-[#1A1A1A] p-1.5 rounded-[4px] hover:bg-[#F5F5F5] transition"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto max-h-[70vh] space-y-4">
          {savedPlaces.length === 0 ? (
            <div className="text-center py-12 px-4 border-2 border-dashed border-[#E5E5E5] rounded-[4px]">
              <MapPin className="w-10 h-10 text-[#CCCCCC] mx-auto mb-3" />
              <p className="text-[16px] font-medium text-[#1A1A1A]">No places saved yet</p>
              <p className="text-[14px] text-[#666666] mt-1 max-w-sm mx-auto">
                Click &quot;Save Place&quot; on any moment shared by trip members to collect spots you want to visit again later!
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="flex items-center justify-between text-[14px] text-[#666666]">
                <span>Showing {savedPlaces.length} curated {savedPlaces.length === 1 ? 'place' : 'places'}</span>
              </div>

              {savedPlaces.map((place, index) => (
                <div
                  key={`${place.placeName}-${index}`}
                  className="p-4 border border-[#E5E5E5] rounded-[4px] bg-[#FFFFFF] hover:border-[#00C853]/60 transition flex flex-col sm:flex-row gap-4 justify-between"
                >
                  <div className="flex gap-3 flex-1">
                    {place.photoUrl ? (
                      <img
                        src={place.photoUrl}
                        alt={place.placeName}
                        className="w-20 h-20 rounded-[4px] object-cover shrink-0 border border-[#E5E5E5]"
                      />
                    ) : (
                      <div className="w-20 h-20 rounded-[4px] bg-[#FAFAFA] border border-[#E5E5E5] flex items-center justify-center shrink-0 text-[#00C853]">
                        <MapPin className="w-8 h-8" />
                      </div>
                    )}

                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <h3 className="font-bold text-[16px] text-[#1A1A1A]">
                          {place.placeName}
                        </h3>
                        {place.category && (
                          <span className="text-[14px] px-2 py-0.5 bg-[#F0F0F0] text-[#444444] rounded-[4px]">
                            {place.category}
                          </span>
                        )}
                      </div>

                      {place.address && (
                        <p className="text-[14px] text-[#666666] flex items-center gap-1">
                          <MapPin className="w-3.5 h-3.5 text-[#00C853]" />
                          {place.address}
                        </p>
                      )}

                      {place.note && (
                        <p className="text-[14px] text-[#333333] italic line-clamp-2 mt-1">
                          &quot;{place.note}&quot;
                        </p>
                      )}

                      <div className="flex items-center gap-2 pt-1 text-[14px] text-[#666666]">
                        <img
                          src={place.recommendedByAvatar}
                          alt={place.recommendedBy}
                          className="w-4 h-4 rounded-full object-cover"
                        />
                        <span>Recommended by <strong className="text-[#1A1A1A]">{place.recommendedBy}</strong></span>
                      </div>
                    </div>
                  </div>

                  <div className="flex sm:flex-col items-center justify-end gap-2 shrink-0 border-t sm:border-t-0 pt-2 sm:pt-0">
                    <button
                      onClick={() => onRemovePlace(place.placeName)}
                      className="text-[14px] text-[#999999] hover:text-[#DD2A7B] px-2.5 py-1 rounded-[4px] hover:bg-[#F5F5F5] transition cursor-pointer"
                    >
                      Remove
                    </button>
                    <a
                      href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(place.placeName + ' ' + (place.address || ''))}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1 text-[14px] text-[#00C853] hover:underline px-2.5 py-1"
                    >
                      <span>Maps</span>
                      <ExternalLink className="w-3.5 h-3.5" />
                    </a>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-3 border-t border-[#E5E5E5] bg-[#FAFAFA] flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-[#1A1A1A] text-white rounded-[4px] text-[14px] font-medium hover:bg-black transition cursor-pointer"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
