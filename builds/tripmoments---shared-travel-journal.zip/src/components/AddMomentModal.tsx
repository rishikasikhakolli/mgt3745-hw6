import React, { useState, useRef } from 'react';
import { Camera, MapPin, FileText, X, AlertTriangle, AlertCircle, RefreshCw, CheckCircle2, Image as ImageIcon, Sparkles, User } from 'lucide-react';
import { TripMember, TripMoment } from '../types';
import { SAMPLE_PRESET_PHOTOS } from '../data/initialData';

interface AddMomentModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAddMoment: (moment: Omit<TripMoment, 'id' | 'timestamp' | 'reactions'>) => Promise<boolean>;
  members: TripMember[];
  currentMemberId: string;
  onSwitchMember: (memberId: string) => void;
  initialValues?: {
    photoUrl?: string;
    note?: string;
    placeName?: string;
    placeAddress?: string;
    simulateFailure?: boolean;
    triggerRefusalImmediately?: boolean;
  };
}

export const AddMomentModal: React.FC<AddMomentModalProps> = ({
  isOpen,
  onClose,
  onAddMoment,
  members,
  currentMemberId,
  onSwitchMember,
  initialValues
}) => {
  // Form state
  const [selectedMemberId, setSelectedMemberId] = useState<string>(currentMemberId);
  const [photoUrl, setPhotoUrl] = useState<string>(initialValues?.photoUrl || '');
  const [photoCaption, setPhotoCaption] = useState<string>('');
  const [note, setNote] = useState<string>(initialValues?.note || '');
  const [placeName, setPlaceName] = useState<string>(initialValues?.placeName || '');
  const [placeAddress, setPlaceAddress] = useState<string>(initialValues?.placeAddress || '');
  const [placeCategory, setPlaceCategory] = useState<string>('');

  // UI / Status state
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [validationError, setValidationError] = useState<string | null>(
    initialValues?.triggerRefusalImmediately
      ? 'Submission refused: A moment must contain at least one of: a photo, a note, or a place. Please provide at least one before saving.'
      : null
  );
  const [saveFailureError, setSaveFailureError] = useState<string | null>(null);
  const [simulateFailure, setSimulateFailure] = useState<boolean>(
    initialValues?.simulateFailure || false
  );
  const [showPresets, setShowPresets] = useState<boolean>(false);

  // Sync initialValues when modal opens with new config
  React.useEffect(() => {
    if (initialValues) {
      if (initialValues.photoUrl !== undefined) setPhotoUrl(initialValues.photoUrl);
      if (initialValues.note !== undefined) setNote(initialValues.note);
      if (initialValues.placeName !== undefined) setPlaceName(initialValues.placeName);
      if (initialValues.simulateFailure !== undefined) setSimulateFailure(initialValues.simulateFailure);
      if (initialValues.triggerRefusalImmediately) {
        setValidationError(
          'Submission refused: A moment must contain at least one of: a photo, a note, or a place. Please provide at least one before saving.'
        );
      } else {
        setValidationError(null);
      }
      setSaveFailureError(null);
    }
  }, [initialValues]);

  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const currentMember = members.find(m => m.id === selectedMemberId) || members[0];

  const hasPhoto = Boolean(photoUrl && photoUrl.trim());
  const hasNote = Boolean(note && note.trim());
  const hasPlace = Boolean(placeName && placeName.trim());
  const hasAtLeastOne = hasPhoto || hasNote || hasPlace;

  // Handle local image file upload
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        if (typeof reader.result === 'string') {
          setPhotoUrl(reader.result);
          setValidationError(null);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSelectPreset = (preset: typeof SAMPLE_PRESET_PHOTOS[0]) => {
    setPhotoUrl(preset.url);
    if (!placeName) {
      setPlaceName(preset.place);
      setPlaceCategory(preset.category);
    }
    setShowPresets(false);
    setValidationError(null);
  };

  const clearPhoto = () => {
    setPhotoUrl('');
    setPhotoCaption('');
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const clearPlace = () => {
    setPlaceName('');
    setPlaceAddress('');
    setPlaceCategory('');
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setValidationError(null);
    setSaveFailureError(null);

    // CRITICAL ACCEPTANCE CRITERION 3:
    // IF a member submits a moment with no photo, note, or place, THEN the app shall refuse and add nothing.
    if (!hasAtLeastOne) {
      setValidationError(
        'Submission refused: A moment must contain at least one of: a photo, a note, or a place. Please provide at least one before saving.'
      );
      return;
    }

    setIsSubmitting(true);

    try {
      // CRITICAL ACCEPTANCE CRITERION 2:
      // IF a review fails to save, THEN the app shall tell the member and keep the photo, note, and location on screen so they can try again.
      if (simulateFailure) {
        // Artificial simulated network failure
        await new Promise((resolve) => setTimeout(resolve, 600));
        throw new Error('Network timeout: Could not connect to trip cloud storage. Server returned 503.');
      }

      // CRITICAL ACCEPTANCE CRITERION 1:
      // WHEN a member submits a moment with at least one of a photo, note, or place, the app shall add it to the trip, labeled with the member's name.
      const momentData: Omit<TripMoment, 'id' | 'timestamp' | 'reactions'> = {
        tripId: 'trip-japan-2026',
        memberId: currentMember.id,
        memberName: currentMember.name,
        memberAvatar: currentMember.avatar,
        photoUrl: hasPhoto ? photoUrl : undefined,
        photoCaption: hasPhoto && photoCaption.trim() ? photoCaption.trim() : undefined,
        note: hasNote ? note.trim() : undefined,
        place: hasPlace
          ? {
              name: placeName.trim(),
              address: placeAddress.trim() || undefined,
              category: placeCategory.trim() || 'Spot'
            }
          : undefined,
        dayNumber: 2
      };

      const success = await onAddMoment(momentData);

      if (success) {
        // Successfully saved: reset form and close
        setPhotoUrl('');
        setPhotoCaption('');
        setNote('');
        setPlaceName('');
        setPlaceAddress('');
        setPlaceCategory('');
        setValidationError(null);
        setSaveFailureError(null);
        onClose();
      } else {
        throw new Error('Save operation was not acknowledged.');
      }
    } catch (err: unknown) {
      // Notice: DO NOT clear photo, note, or place! Keep them intact on screen!
      const errorMsg =
        err instanceof Error ? err.message : 'Unknown connection error occurred.';
      setSaveFailureError(
        `Review failed to save: ${errorMsg} Your photo, note, and place are kept on screen so you can try again immediately.`
      );
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 overflow-y-auto">
      <div 
        className="bg-[#FFFFFF] text-[#1A1A1A] w-full max-w-xl rounded-[4px] shadow-2xl border border-[#E5E5E5] my-8 overflow-hidden flex flex-col"
        role="dialog"
        aria-modal="true"
        aria-labelledby="modal-title"
      >
        {/* Modal Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-[#E5E5E5] bg-[#FFFFFF]">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-[#DD2A7B]"></span>
            <h2 id="modal-title" className="font-heading text-[20px] font-bold text-[#1A1A1A]">
              Add a Moment to Trip
            </h2>
          </div>
          <button
            onClick={onClose}
            type="button"
            className="text-[#666666] hover:text-[#1A1A1A] p-1.5 rounded-[4px] hover:bg-[#F5F5F5] transition"
            aria-label="Close modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          
          {/* Member Attribution Selector (Labeled with member's name) */}
          <div className="bg-[#FAFAFA] p-4 rounded-[4px] border border-[#E5E5E5]">
            <label className="block text-[14px] font-medium text-[#1A1A1A] mb-2 flex items-center justify-between">
              <span className="flex items-center gap-1.5">
                <User className="w-4 h-4 text-[#DD2A7B]" />
                Posting as Member:
              </span>
              <span className="text-[14px] text-[#666666]">
                Trip moment will be labeled with this name
              </span>
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {members.map((member) => (
                <button
                  type="button"
                  key={member.id}
                  onClick={() => {
                    setSelectedMemberId(member.id);
                    onSwitchMember(member.id);
                  }}
                  className={`flex items-center gap-2 p-2 rounded-[4px] border text-left transition ${
                    selectedMemberId === member.id
                      ? 'border-[#DD2A7B] bg-[#DD2A7B]/10 text-[#DD2A7B] font-medium shadow-sm'
                      : 'border-[#E5E5E5] bg-[#FFFFFF] hover:bg-[#F0F0F0] text-[#1A1A1A]'
                  }`}
                >
                  <img
                    src={member.avatar}
                    alt={member.name}
                    className="w-7 h-7 rounded-full object-cover shrink-0"
                  />
                  <div className="truncate">
                    <div className="text-[14px] leading-tight truncate">{member.name}</div>
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* CRITICAL: Acceptance Criteria 3 Refusal Notification */}
          {validationError && (
            <div className="bg-[#FFF0F2] border-l-4 border-[#DD2A7B] p-4 rounded-[4px] flex items-start gap-3">
              <AlertCircle className="w-5 h-5 text-[#DD2A7B] shrink-0 mt-0.5" />
              <div>
                <p className="font-bold text-[#DD2A7B] text-[14px]">Refused: Missing Content</p>
                <p className="text-[#1A1A1A] text-[14px] mt-0.5">{validationError}</p>
                <p className="text-[14px] text-[#666666] mt-1 italic">
                  Tip: Upload a photo, write a note, or name a place you visited. At least one is required.
                </p>
              </div>
            </div>
          )}

          {/* CRITICAL: Acceptance Criteria 2 Failure Notification & Preserved Content Notice */}
          {saveFailureError && (
            <div className="bg-[#FFF8E1] border-l-4 border-[#F57C00] p-4 rounded-[4px] flex flex-col gap-3">
              <div className="flex items-start gap-3">
                <AlertTriangle className="w-5 h-5 text-[#F57C00] shrink-0 mt-0.5" />
                <div className="flex-1">
                  <p className="font-bold text-[#F57C00] text-[14px]">Save Failed</p>
                  <p className="text-[#1A1A1A] text-[14px] mt-0.5">{saveFailureError}</p>
                </div>
              </div>
              <div className="flex items-center justify-between pt-2 border-t border-[#FFE082]/60">
                <span className="text-[14px] text-[#666666]">
                  Inputs preserved. Click below to re-attempt.
                </span>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="inline-flex items-center gap-1.5 px-4 py-2 bg-[#F57C00] text-[#FFFFFF] rounded-[4px] text-[14px] font-medium hover:bg-[#E65100] transition cursor-pointer shadow-sm"
                >
                  <RefreshCw className={`w-4 h-4 ${isSubmitting ? 'animate-spin' : ''}`} />
                  Try Again Now
                </button>
              </div>
            </div>
          )}

          {/* Section 1: Photo (Optional if note or place provided) */}
          <div className={`p-4 rounded-[4px] border ${validationError && !hasPhoto ? 'border-[#DD2A7B]/40 bg-[#FFF5F7]' : 'border-[#E5E5E5] bg-[#FFFFFF]'}`}>
            <div className="flex items-center justify-between mb-2">
              <label className="text-[14px] font-medium text-[#1A1A1A] flex items-center gap-1.5">
                <Camera className="w-4 h-4 text-[#DD2A7B]" />
                1. Trip Photo <span className="text-[#666666] font-normal">(Optional if note or place given)</span>
              </label>
              {hasPhoto && (
                <button
                  type="button"
                  onClick={clearPhoto}
                  className="text-[14px] text-[#DD2A7B] hover:underline"
                >
                  Remove photo
                </button>
              )}
            </div>

            {hasPhoto ? (
              <div className="space-y-3">
                <div className="relative rounded-[4px] overflow-hidden border border-[#E5E5E5] max-h-56 bg-black/5 flex items-center justify-center">
                  <img
                    src={photoUrl}
                    alt="Trip moment preview"
                    className="w-full h-56 object-cover"
                  />
                  <div className="absolute bottom-2 right-2 bg-black/70 text-white text-[14px] px-2 py-1 rounded-[4px]">
                    Photo attached
                  </div>
                </div>
                <div>
                  <input
                    type="text"
                    value={photoCaption}
                    onChange={(e) => setPhotoCaption(e.target.value)}
                    placeholder="Add an optional photo caption..."
                    className="w-full px-3 py-2 border border-[#E5E5E5] rounded-[4px] text-[14px] focus:outline-none focus:border-[#DD2A7B]"
                  />
                </div>
              </div>
            ) : (
              <div className="space-y-2">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*"
                    onChange={handleFileChange}
                    className="hidden"
                    id="photo-file-input"
                  />
                  <label
                    htmlFor="photo-file-input"
                    className="flex items-center justify-center gap-2 p-3 border-2 border-dashed border-[#CCCCCC] hover:border-[#DD2A7B] rounded-[4px] cursor-pointer text-[#1A1A1A] hover:bg-[#FAFAFA] text-[14px] transition text-center"
                  >
                    <ImageIcon className="w-4 h-4 text-[#DD2A7B]" />
                    Upload from Device
                  </label>

                  <button
                    type="button"
                    onClick={() => setShowPresets(!showPresets)}
                    className="flex items-center justify-center gap-2 p-3 border border-[#E5E5E5] rounded-[4px] bg-[#FAFAFA] hover:bg-[#F0F0F0] text-[14px] text-[#1A1A1A] transition"
                  >
                    <Sparkles className="w-4 h-4 text-[#00C853]" />
                    {showPresets ? 'Hide Sample Photos' : 'Choose Travel Shot'}
                  </button>
                </div>

                {/* Presets Gallery Drawer */}
                {showPresets && (
                  <div className="p-3 bg-[#F9F9F9] rounded-[4px] border border-[#E5E5E5] mt-2">
                    <p className="text-[14px] text-[#666666] mb-2 font-medium">
                      Select a travel photograph:
                    </p>
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                      {SAMPLE_PRESET_PHOTOS.map((preset, idx) => (
                        <div
                          key={idx}
                          onClick={() => handleSelectPreset(preset)}
                          className="cursor-pointer group relative rounded-[4px] overflow-hidden border border-[#CCCCCC] hover:border-[#DD2A7B]"
                        >
                          <img
                            src={preset.url}
                            alt={preset.label}
                            className="w-full h-20 object-cover group-hover:scale-105 transition"
                          />
                          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent flex items-end p-1">
                            <span className="text-[14px] text-white truncate drop-shadow">
                              {preset.label}
                            </span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Section 2: Note / Story (Optional if photo or place provided) */}
          <div className={`p-4 rounded-[4px] border ${validationError && !hasNote ? 'border-[#DD2A7B]/40 bg-[#FFF5F7]' : 'border-[#E5E5E5] bg-[#FFFFFF]'}`}>
            <div className="flex items-center justify-between mb-2">
              <label className="text-[14px] font-medium text-[#1A1A1A] flex items-center gap-1.5">
                <FileText className="w-4 h-4 text-[#DD2A7B]" />
                2. Note or Story <span className="text-[#666666] font-normal">(Optional if photo or place given)</span>
              </label>
              {hasNote && (
                <button
                  type="button"
                  onClick={() => setNote('')}
                  className="text-[14px] text-[#666666] hover:text-[#1A1A1A]"
                >
                  Clear note
                </button>
              )}
            </div>
            <textarea
              value={note}
              onChange={(e) => {
                setNote(e.target.value);
                setValidationError(null);
              }}
              rows={3}
              placeholder="What happened? Share a funny inside joke, quick story, food review, or tips for the crew..."
              className="w-full px-3 py-2 border border-[#E5E5E5] rounded-[4px] text-[14px] text-[#1A1A1A] focus:outline-none focus:border-[#DD2A7B] resize-y placeholder-[#888888]"
            />
            <div className="flex items-center justify-between mt-1 text-[14px] text-[#666666]">
              <span>In-the-moment notes stay with the trip</span>
              <span>{note.length} characters</span>
            </div>
          </div>

          {/* Section 3: Place / Location (Optional if photo or note provided) */}
          <div className={`p-4 rounded-[4px] border ${validationError && !hasPlace ? 'border-[#DD2A7B]/40 bg-[#FFF5F7]' : 'border-[#E5E5E5] bg-[#FFFFFF]'}`}>
            <div className="flex items-center justify-between mb-2">
              <label className="text-[14px] font-medium text-[#1A1A1A] flex items-center gap-1.5">
                <MapPin className="w-4 h-4 text-[#00C853]" />
                3. Place or Spot <span className="text-[#666666] font-normal">(Optional if photo or note given)</span>
              </label>
              {hasPlace && (
                <button
                  type="button"
                  onClick={clearPlace}
                  className="text-[14px] text-[#DD2A7B] hover:underline"
                >
                  Remove place
                </button>
              )}
            </div>

            <div className="space-y-2">
              <div>
                <input
                  type="text"
                  value={placeName}
                  onChange={(e) => {
                    setPlaceName(e.target.value);
                    setValidationError(null);
                  }}
                  placeholder="Spot or venue name (e.g., Fushimi Inari, Bar Trench, Golden Gai)"
                  className="w-full px-3 py-2 border border-[#E5E5E5] rounded-[4px] text-[14px] text-[#1A1A1A] focus:outline-none focus:border-[#DD2A7B]"
                />
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                <input
                  type="text"
                  value={placeAddress}
                  onChange={(e) => setPlaceAddress(e.target.value)}
                  placeholder="Address or neighborhood (e.g., Shinjuku, Tokyo)"
                  className="w-full px-3 py-2 border border-[#E5E5E5] rounded-[4px] text-[14px] text-[#1A1A1A] focus:outline-none focus:border-[#DD2A7B]"
                />
                <select
                  value={placeCategory}
                  onChange={(e) => setPlaceCategory(e.target.value)}
                  className="w-full px-3 py-2 border border-[#E5E5E5] rounded-[4px] text-[14px] text-[#1A1A1A] focus:outline-none focus:border-[#DD2A7B] bg-white"
                >
                  <option value="">Select Category (Optional)</option>
                  <option value="Food & Dining">Food & Dining</option>
                  <option value="Hidden Gem">Hidden Gem</option>
                  <option value="Scenic & Nature">Scenic & Nature</option>
                  <option value="Music & Culture">Music & Culture</option>
                  <option value="Nightlife & Bar">Nightlife & Bar</option>
                  <option value="Coffee & Cafe">Coffee & Cafe</option>
                </select>
              </div>
            </div>
          </div>

          {/* Testing Control for Acceptance Criterion 2 (Simulate Save Failure) */}
          <div className="p-3 bg-[#F5F5F5] border border-[#E0E0E0] rounded-[4px] flex items-center justify-between">
            <div className="flex items-center gap-2">
              <input
                type="checkbox"
                id="simulate-fail-checkbox"
                checked={simulateFailure}
                onChange={(e) => setSimulateFailure(e.target.checked)}
                className="w-4 h-4 text-[#DD2A7B] rounded-[4px] accent-[#DD2A7B] cursor-pointer"
              />
              <label htmlFor="simulate-fail-checkbox" className="text-[14px] text-[#1A1A1A] cursor-pointer select-none">
                <span className="font-semibold text-[#DD2A7B]">Test AC 2:</span> Simulate review save failure
              </label>
            </div>
            <span className="text-[14px] text-[#666666] hidden sm:inline">
              {simulateFailure ? 'Will fail & preserve screen' : 'Normal save'}
            </span>
          </div>

          {/* Validation Status Indicator */}
          <div className="text-[14px] text-[#666666] flex items-center gap-2">
            {hasAtLeastOne ? (
              <span className="flex items-center gap-1.5 text-[#00C853] font-medium">
                <CheckCircle2 className="w-4 h-4" /> Ready to save: includes{' '}
                {[hasPhoto && 'photo', hasNote && 'note', hasPlace && 'place']
                  .filter(Boolean)
                  .join(' + ')}
              </span>
            ) : (
              <span className="text-[#888888]">
                At least one required (photo, note, or place)
              </span>
            )}
          </div>

          {/* Modal Footer Actions */}
          <div className="flex items-center justify-between pt-4 border-t border-[#E5E5E5]">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-[14px] font-medium text-[#666666] hover:text-[#1A1A1A] rounded-[4px] hover:bg-[#F5F5F5] transition"
            >
              Cancel
            </button>

            <div className="flex items-center gap-2">
              <button
                type="submit"
                disabled={isSubmitting}
                className="inline-flex items-center justify-center gap-2 px-6 py-2.5 bg-[#DD2A7B] hover:bg-[#C9226E] text-[#FFFFFF] rounded-[4px] text-[14px] font-medium transition cursor-pointer shadow-sm disabled:opacity-50"
              >
                {isSubmitting ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    Saving Moment...
                  </>
                ) : (
                  <>
                    Share Moment as {currentMember.name}
                  </>
                )}
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};
