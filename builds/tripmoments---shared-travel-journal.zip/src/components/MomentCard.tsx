import React, { useState } from 'react';
import { MapPin, Bookmark, MessageCircle, Heart, Share2, Trash2, Calendar, Check, ExternalLink } from 'lucide-react';
import { TripMoment } from '../types';

interface MomentCardProps {
  moment: TripMoment;
  currentUserId: string;
  currentUserName: string;
  isPlaceSaved: boolean;
  onToggleSavePlace: (placeName: string, moment: TripMoment) => void;
  onReaction: (momentId: string, emoji: string) => void;
  onDeleteMoment: (momentId: string) => void;
  onAddComment?: (momentId: string, text: string) => void;
}

export const MomentCard: React.FC<MomentCardProps> = ({
  moment,
  currentUserId,
  currentUserName,
  isPlaceSaved,
  onToggleSavePlace,
  onReaction,
  onDeleteMoment,
  onAddComment
}) => {
  const [showCommentInput, setShowCommentInput] = useState(false);
  const [commentText, setCommentText] = useState('');
  const [imageModalOpen, setImageModalOpen] = useState(false);

  // Format date readable
  const formattedDate = new Date(moment.timestamp).toLocaleTimeString([], {
    hour: '2-digit',
    minute: '2-digit'
  });

  const availableEmojis = ['❤️', '🔥', '😂', '👏', '📍'];

  const handleCommentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!commentText.trim() || !onAddComment) return;
    onAddComment(moment.id, commentText.trim());
    setCommentText('');
  };

  return (
    <article 
      className="bg-[#FFFFFF] border border-[#E5E5E5] rounded-[4px] overflow-hidden shadow-xs hover:border-[#D0D0D0] transition mb-6"
      aria-label={`Moment by ${moment.memberName}`}
    >
      {/* Card Header: Prominently Labeled with Member's Name (AC 1) */}
      <div className="flex items-center justify-between p-4 border-b border-[#F0F0F0]">
        <div className="flex items-center gap-3">
          {/* Avatar with primary color highlight ring */}
          <div className="relative p-0.5 rounded-full bg-gradient-to-tr from-[#FFD600] via-[#DD2A7B] to-[#9900FA]">
            <img
              src={moment.memberAvatar}
              alt={moment.memberName}
              className="w-10 h-10 rounded-full object-cover border-2 border-[#FFFFFF]"
            />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-bold text-[#1A1A1A] text-[15px] leading-tight">
                {moment.memberName}
              </span>
              {moment.memberId === currentUserId && (
                <span className="text-[14px] bg-[#DD2A7B]/10 text-[#DD2A7B] font-medium px-2 py-0.5 rounded-[4px]">
                  You
                </span>
              )}
            </div>
            <div className="flex items-center gap-2 text-[14px] text-[#666666] mt-0.5">
              <span>{formattedDate}</span>
              <span>•</span>
              <span className="flex items-center gap-1">
                <Calendar className="w-3.5 h-3.5" />
                Day {moment.dayNumber || 1}
              </span>
            </div>
          </div>
        </div>

        {/* Delete / Action Options */}
        <div className="flex items-center gap-1">
          {moment.memberId === currentUserId && (
            <button
              onClick={() => onDeleteMoment(moment.id)}
              className="text-[#999999] hover:text-[#DD2A7B] p-2 rounded-[4px] hover:bg-[#F5F5F5] transition cursor-pointer"
              title="Delete moment"
              aria-label="Delete moment"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      {/* Place Badge (if moment has a place) */}
      {moment.place && (
        <div className="px-4 py-2.5 bg-[#F9F9F9] border-b border-[#F0F0F0] flex items-center justify-between">
          <div className="flex items-center gap-2 overflow-hidden">
            <span className="p-1 rounded-[4px] bg-[#00C853]/15 text-[#00C853]">
              <MapPin className="w-4 h-4 shrink-0" />
            </span>
            <div className="truncate">
              <span className="font-semibold text-[#1A1A1A] text-[14px]">
                {moment.place.name}
              </span>
              {moment.place.address && (
                <span className="text-[14px] text-[#666666] ml-2 truncate hidden sm:inline">
                  — {moment.place.address}
                </span>
              )}
            </div>
          </div>

          {/* User 3 (Semaj) Feature: Bookmark / Save Place from friends */}
          <button
            onClick={() => onToggleSavePlace(moment.place!.name, moment)}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-[4px] text-[14px] font-medium transition cursor-pointer shrink-0 ${
              isPlaceSaved
                ? 'bg-[#00C853] text-[#FFFFFF]'
                : 'bg-[#FFFFFF] border border-[#CCCCCC] hover:border-[#00C853] text-[#1A1A1A]'
            }`}
            title={isPlaceSaved ? 'Place saved in your trip list' : 'Save place to your recommendations'}
          >
            {isPlaceSaved ? (
              <>
                <Check className="w-3.5 h-3.5" />
                <span>Saved</span>
              </>
            ) : (
              <>
                <Bookmark className="w-3.5 h-3.5 text-[#00C853]" />
                <span>Save Place</span>
              </>
            )}
          </button>
        </div>
      )}

      {/* Photo Section (if moment has a photo) */}
      {moment.photoUrl && (
        <div className="bg-[#000000] relative">
          <img
            src={moment.photoUrl}
            alt={moment.photoCaption || `Trip photo by ${moment.memberName}`}
            className="w-full max-h-[500px] object-cover cursor-pointer hover:opacity-95 transition"
            onClick={() => setImageModalOpen(true)}
          />
          {moment.photoCaption && (
            <div className="px-4 py-2 bg-[#1A1A1A] text-white text-[14px] border-t border-[#333333]">
              {moment.photoCaption}
            </div>
          )}
        </div>
      )}

      {/* Note / Story Section (if moment has a note) */}
      {moment.note && (
        <div className="p-4">
          <p className="text-[15px] leading-relaxed text-[#1A1A1A] whitespace-pre-line font-body">
            {moment.note}
          </p>
        </div>
      )}

      {/* Lightweight Friend Interactions (User 1 Rishika: react without conversation pressure) */}
      <div className="px-4 py-3 bg-[#FFFFFF] border-t border-[#F0F0F0]">
        <div className="flex items-center justify-between flex-wrap gap-2">
          {/* Reaction buttons */}
          <div className="flex items-center gap-1.5 flex-wrap">
            {availableEmojis.map((emoji) => {
              const reactedList = moment.reactions?.[emoji] || [];
              const hasReacted = reactedList.includes(currentUserName);
              return (
                <button
                  key={emoji}
                  onClick={() => onReaction(moment.id, emoji)}
                  className={`flex items-center gap-1 px-2.5 py-1 rounded-[4px] text-[14px] transition cursor-pointer border ${
                    hasReacted
                      ? 'border-[#DD2A7B] bg-[#DD2A7B]/10 font-medium'
                      : 'border-[#E5E5E5] bg-[#FAFAFA] hover:bg-[#F0F0F0]'
                  }`}
                  title={reactedList.length > 0 ? `Reacted by ${reactedList.join(', ')}` : `React with ${emoji}`}
                >
                  <span>{emoji}</span>
                  {reactedList.length > 0 && (
                    <span className="text-[14px] text-[#1A1A1A] font-semibold">
                      {reactedList.length}
                    </span>
                  )}
                </button>
              );
            })}
          </div>

          {/* Quick Comment Toggle */}
          <button
            onClick={() => setShowCommentInput(!showCommentInput)}
            className="flex items-center gap-1.5 text-[14px] text-[#666666] hover:text-[#1A1A1A] px-2.5 py-1 rounded-[4px] hover:bg-[#F5F5F5] transition cursor-pointer"
          >
            <MessageCircle className="w-4 h-4 text-[#DD2A7B]" />
            <span>{moment.comments?.length ? `${moment.comments.length} replies` : 'Reply'}</span>
          </button>
        </div>

        {/* Comment Thread */}
        {moment.comments && moment.comments.length > 0 && (
          <div className="mt-3 pt-3 border-t border-[#F0F0F0] space-y-2">
            {moment.comments.map((comment) => (
              <div key={comment.id} className="text-[14px] flex items-start gap-2 bg-[#FAFAFA] p-2 rounded-[4px]">
                <span className="font-semibold text-[#1A1A1A] shrink-0">{comment.memberName}:</span>
                <span className="text-[#1A1A1A] flex-1">{comment.text}</span>
              </div>
            ))}
          </div>
        )}

        {/* Comment Input */}
        {showCommentInput && (
          <form onSubmit={handleCommentSubmit} className="mt-3 flex gap-2">
            <input
              type="text"
              value={commentText}
              onChange={(e) => setCommentText(e.target.value)}
              placeholder={`Reply to ${moment.memberName}'s moment...`}
              className="flex-1 px-3 py-1.5 border border-[#E5E5E5] rounded-[4px] text-[14px] focus:outline-none focus:border-[#DD2A7B]"
            />
            <button
              type="submit"
              disabled={!commentText.trim()}
              className="px-3 py-1.5 bg-[#DD2A7B] text-[#FFFFFF] rounded-[4px] text-[14px] font-medium hover:bg-[#C9226E] disabled:opacity-50 transition cursor-pointer"
            >
              Send
            </button>
          </form>
        )}
      </div>

      {/* Lightbox Modal for Photo */}
      {imageModalOpen && moment.photoUrl && (
        <div
          className="fixed inset-0 z-50 bg-black/90 flex items-center justify-center p-4"
          onClick={() => setImageModalOpen(false)}
        >
          <div className="max-w-4xl max-h-[90vh] relative" onClick={(e) => e.stopPropagation()}>
            <img
              src={moment.photoUrl}
              alt={moment.photoCaption || 'Full view'}
              className="max-h-[85vh] w-auto rounded-[4px] object-contain shadow-2xl"
            />
            <div className="mt-2 text-center text-white text-[14px]">
              {moment.photoCaption || `${moment.memberName}'s photo`}
            </div>
            <button
              onClick={() => setImageModalOpen(false)}
              className="absolute -top-10 right-0 text-white hover:text-[#DD2A7B] text-[14px] font-bold p-1 cursor-pointer"
            >
              Close [✕]
            </button>
          </div>
        </div>
      )}
    </article>
  );
};
