export interface TripMember {
  id: string;
  name: string;
  avatar: string;
  role: string;
  handle: string;
  bio?: string;
}

export interface TripMoment {
  id: string;
  tripId: string;
  memberId: string;
  memberName: string;
  memberAvatar: string;
  photoUrl?: string;
  photoCaption?: string;
  note?: string;
  place?: {
    name: string;
    address?: string;
    category?: string;
    googleMapsQuery?: string;
  };
  timestamp: string; // ISO string
  dayNumber?: number;
  reactions: Record<string, string[]>; // emoji -> array of member names
  savedBy?: string[]; // list of member IDs who saved the place
  comments?: Array<{
    id: string;
    memberName: string;
    text: string;
    timestamp: string;
  }>;
}

export interface Trip {
  id: string;
  title: string;
  dates: string;
  destination: string;
  coverImage: string;
  description: string;
  members: TripMember[];
}
